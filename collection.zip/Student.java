package collection;
import java.util.Objects;
import java.util.UUID;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;
public class Student {
    private int id;
    private String name;
    private int age;
    private String address;
    private String email;
    Student(Student s){
        this.id = s.id;
        this.name = s.name;
        this.age = s.age;
        this.address = s.address;
        this.email = s.email;
    }
    Student(String name,int age,String address,String email){
        this.id = UUID.randomUUID().hashCode();
        this.name = name;
        this.age = age;
        this.address = address;
        this.email = email;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;

        return result;
    }
    
    @Override
public boolean equals(Object obj) {
    if (this == obj) 
        return true;
    if (obj == null) 
        return false;
    if (getClass() != obj.getClass()) 
        return false;
    Student other = (Student) obj; 
    
    return id == other.id; 
}

     @Override
    public String toString() {
        return "Name: " + name + 
               ", Age: " + age + 
               ", Address: " + address + 
               ", Email: " + email;
    }
    private static void ArrayListDemo(Student... s){
        ArrayList<Student> a = new ArrayList<>();
        for(int i=0;i<s.length;i++){
            a.add(s[i]);
        }
        System.out.println("Addition of all Objects");
        for(Student p: a){
            System.out.println(p);
        }
        System.out.println();
        System.out.println("Addition at position");
        Student newStudent = new Student("Karthik", 21, "Madurai", "karthik@123");
        int pos = 2;
        a.add(pos, newStudent); 
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Remove by index");
        a.remove(3);
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Remove by element");
        a.remove(newStudent);
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println("Addition and remove by position in middle cause more time in swapping of elements");
        System.out.println();
    }
    private static void LinkedListDemo(Student... s){
        LinkedList<Student> a = new LinkedList<>();
        for(int i=0;i<s.length;i++){
            a.add(s[i]);
        }
        System.out.println("Addition of all Objects");
        for(Student p: a){
            System.out.println(p);
        }
        System.out.println();
        System.out.println("Addition at position");
        Student newStudent = new Student("Karthik", 21, "Madurai", "karthik@123");
        a.add(2, newStudent); 
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Remove by index");
        a.remove(3);
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Remove by element");
        a.remove(newStudent);
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println("Addition and remove by position in middle cause less time in swapping of elements cause there is no coonection for all elements only 3 nodes changes its next/previous");
        System.out.println();
    }
    private static void HashSet(Student... s){
        HashSet<Student> a = new HashSet<>();
        for(int i=0;i<s.length;i++){
            a.add(s[i]);
        }
        System.out.println("Addition of all Objects");
        for(Student p: a){
            System.out.println(p);
        }
        System.out.println();
        System.out.println("Addition new");
        Student newStudent = new Student("Karthik", 21, "Madurai", "karthik@123");
        a.add(newStudent); 
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Remove by element");
        a.remove(newStudent);
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("tried to add same element");
        a.add(s[s.length-1]); 
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Duplicate Objects are not allowed,Insertion order is not maintained, all Must be unique Objects");
        System.out.println();
    }
    private static void LinkedHashSet(Student... s){
        LinkedHashSet<Student> a = new LinkedHashSet<>();
        for(int i=s.length-1;i>=0;i--){
            a.add(s[i]);
        }
        System.out.println("Addition of all Objects");
        for(Student p: a){
            System.out.println(p);
        }
        System.out.println();
        System.out.println("Addition new");
        Student newStudent = new Student("Karthik", 21, "Madurai", "karthik@123");
        a.add(newStudent); 
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Remove by element");
        a.remove(newStudent);
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("tried to add same element");
        a.add(s[s.length-1]); 
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Duplicates are not allowed , Insertion order is maintained, All must be Unique");
        System.out.println();
    }
    private static void TreeSet(Student... s){
        TreeSet<Student> a = new TreeSet<>();
        for(int i=s.length-1;i>=0;i--){
            a.add(s[i]);
        }
        System.out.println("Addition of all Objects");
        for(Student p: a){
            System.out.println(p);
        }
        System.out.println();
        System.out.println("Addition new");
        Student newStudent = new Student("Karthik", 21, "Madurai", "karthik@123");
        a.add(newStudent); 
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Remove by element");
        a.remove(newStudent);
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("tried to add same element");
        a.add(s[s.length-1]); 
        for (Student p : a) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Duplicates are eliminated without any caution, Insertion order is not maintained, All Objects are unique, Sorted based on, Balanced Binary Search Tree");
        System.out.println();
    }
    private static void HashMap(Student... s){
        HashMap<Integer,Student> a =new HashMap<>();
        for(int i=0;i<s.length;i++){
            a.put(s[i].id, s[i]);
        }
        for(Student p: a.values()){
            System.out.println(p);
        }
        System.out.println();
        System.out.println("Addition new");
        Student newStudent = new Student("Karthik", 21, "Madurai", "karthik@123");
        a.put(5,newStudent); 
        for (Student p : a.values()) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Addition new");
        Student news = new Student("Kar", 22, "Tenkasi", "kar@123");
        a.put(6,news); 
        for (Student p : a.values()) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Remove by element");
        a.remove(5);
        for (Student p : a.values()) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("tried to add same element");
        a.put(6,new Student("name", 1, "address", "email")); 
        for (Student p : a.values()) {
        System.out.println(p);
        }
        System.out.println();
        System.out.println("Same as HashSet contains key-value pair");
        System.out.println();
    }
    private static void LinkedHashMap(){
        
    }
    private static void TreeMap(){

    }
    public static void main(String[] args) {
        Student selva = new Student("Selva", 22, "Rajapalayam", "selva@123");
        Student sudharsan = new Student("Sudharsan", 22, "Srivi", "sudharsan@123");
        Student magesh = new Student("Magesh", 22, "Srivi", "magesh@123");
        Student sheik = new Student("Sheik", 23, "Kerala", "sheik@123");
        Student join = new Student(selva);
        Student kane = magesh;
        Student lakshman = new Student("Lakshman", 22, "Rajapalayam", "laks@123");
        System.out.println("ARRAY LIST");
        System.out.println(); 
        ArrayListDemo(selva,sudharsan,magesh,sheik,join,lakshman,kane);
        System.out.println();
        System.out.println("LINKED LIST");
        System.out.println();
        LinkedListDemo(selva,sudharsan,magesh,sheik,join,lakshman,kane);
        System.out.println();
        System.out.println("HASH SET");
        System.out.println();
        HashSet(selva,sudharsan,magesh,sheik,join,lakshman,kane);
        System.out.println();
        System.out.println("LINKED HASH SET");
        System.out.println();
        LinkedHashSet(selva,sudharsan,magesh,sheik,join,lakshman,kane);
        System.out.println();
        System.out.println("HASH MAP");
        System.out.println();
        HashMap(selva,sudharsan,magesh,sheik,join,lakshman,kane);
        System.out.println();
    }
}