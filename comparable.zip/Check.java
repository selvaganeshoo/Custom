package comparable;
public abstract class Check {
    private int a;
    protected Check(){
        a = 5;
    }
    public static void add(){
        System.out.println(5);
    }
}
