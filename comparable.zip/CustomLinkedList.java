package comparable;
public class CustomLinkedList<T> {
    private Node<T> head;
    private Node<T> tail;
    private int size;
    class Node<T>{
    private Node<T> prev;
    private Node<T> next;
    private T data;
    Node(T a){
        data = a;
    }
    }
    CustomLinkedList(){
        size =0;
        head =null;
        tail = null;
    }
    public void addlast(T a){
        Node<T> newNode = new Node(a);
        if(head == null && tail == null){
            head = tail = newNode;
            newNode.next = null;
            newNode.prev = null;
        }
        else{
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
            newNode.next = null;
        }
        size++;
    }
    public void addBefore(int pos, T a){
        if(pos<0||pos>size){
            throw new IndexOutOfBoundsException();
        }
        else if(pos == 0){
            if(head == null){
                Node<T> newNode = new Node(a);
                head=tail=newNode;
            }else{
            Node<T> newNode = new Node(a);
            head.prev = newNode;
            newNode.next = head;
            head = newNode;
            newNode.prev = null;
            }
        }
        else if(pos == size){
            addlast(a);
            return;
        }
        else{
            Node<T> newNode = new Node(a);
            Node<T> current = head;
            for(int i=0;i<pos;i++){
                current = current.next;
            }
            Node<T> previous = current.prev;
            previous.next = newNode;
            newNode.prev = previous;
            newNode.next = current;
            current.prev = newNode;
        }
        size++;
    }
    public void remove(T a){
        if(a==null){
            throw new NullPointerException();
        }
        Node<T> current = head;
        while(current!=null){
            if(current.data.equals(a)){
            if(current == head){
               Node<T> nextNode = current.next;
                head = nextNode;
                    if (nextNode != null) {
                        nextNode.prev = null;
                    } else {
                        tail = null; 
                    }
            }
            else if(current == tail){
                Node<T> previous = current.prev;
                tail = previous;
                if(previous!=null){
                    previous.next = null;
                }
                else{
                    head = null;
                }
            }
            else{
                Node<T> previous = current.prev;
                Node<T> nextNode = current.next;
                previous.next = nextNode;
                nextNode.prev = previous;
            }
                current.data = null;
                current.next = null;
                current.prev = null;
                size--;
                break;
            }
            current = current.next;
        }
    }
    public int indexOf(T a){
        if(a==null){
            throw new NullPointerException();
        }
        Node<T> current = head;
        for(int i=0;i<size;i++){
            if(current.data.equals(a)){
                return i;
            }
            current = current.next;
        }
        return -1;
    }
    public T get(int index) {
    if (index < 0 || index >= size) {
        throw new IndexOutOfBoundsException();
    }
    Node<T> current = head;
    for (int i = 0; i < index; i++) {
        current = current.next;
    }
    return current.data;
}

    public int size(){
        return size;
    }
    @Override
    public String toString(){
        StringBuilder bi = new StringBuilder();
        bi.append("[");
        Node<T> current = head;
        for(int i=0;i<size;i++){
            bi.append(current.data);
            if(current.next!=null){
                bi.append(", ");
            }
            current = current.next;
        }
        bi.append("]");
        return bi.toString();
    }
    public static void main(String[] args) {
        CustomLinkedList<Integer> list = new CustomLinkedList<>();
        list.addlast(10);
        list.addlast(20);
        list.addlast(30);
        list.addBefore(1, 15);
        System.out.println(list); 
        System.out.println(list.indexOf(20));
        System.out.println(list.get(2));
        list.remove(10);
        System.out.println(list); 

        list.remove(30);
        System.out.println(list); 

        list.remove(20);
        System.out.println(list); 

        list.remove(15);
        System.out.println(list);

    }
}