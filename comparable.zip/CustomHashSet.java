package comparable;
public class CustomHashSet<K> {
    private Node<? extends K> table[];
    private int DEFAULT_INITIAL_CAPACITY =16; 
    private int size;
    private class Node<K>{
        Node<K> next;
        K key;
        Node(K key){
            this.key = key;
            this.next = null;
        }
    }
    CustomHashSet(){
        table = new Node[DEFAULT_INITIAL_CAPACITY];
        size = 0;
    }
    public void add(K key){
        int hash = Math.abs(key.hashCode())%table.length;
    }
}
