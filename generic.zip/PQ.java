import java.util.ArrayList;
public class PQ {
public static void main(String[] args) {
    ArrayList b = new ArrayList<>();
    b.add("hello");
    b.add(21);
    b.add(90);
    b.add(20.50);
    b.add(1, "hi");
    System.out.println(b);
}
} 

