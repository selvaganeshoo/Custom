
public class AnotherGeneric <O,T> implements Comparable {
    O x;
    T y;
    AnotherGeneric(O x,T y){
        this.x = x;
        this.y = y;
    }
    public T getvalue(String a){
        System.out.println(getValue());
        return y;
    }
    public O getValue(){
        return x;
    }
    @Override
    public int compareTo(Object arg0) {
        throw new UnsupportedOperationException("Unimplemented method 'compareTo'");
    }
}
