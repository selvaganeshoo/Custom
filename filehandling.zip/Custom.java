package filehandling;
import java.io.CharConversionException;
import java.io.DataInputStream;
import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.ArrayList;
import java.util.List;
public class Custom{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Map<MyString, MyString> map = new HashMap<>();
        System.out.print("Enter number of entries: ");
        int n = sc.nextInt();
        sc.nextLine();
        for (int i = 0; i < n; i++) {
            System.out.print("Enter Key: ");
            String keyStr = sc.nextLine();
            System.out.print("Enter Value: ");
            String valueStr = sc.nextLine();

            MyString key = new MyString(keyStr);
            MyString value = new ValueString(valueStr);
            if(map.containsKey(key)){
                System.out.println("Duplicate not added");
                --i;
            }else{
                map.put(key, value);
            }
        }
        System.out.println("\nOutput:");
        List<ValueString> valuesList = new ArrayList<>();
        for (Map.Entry<MyString, MyString> entry : map.entrySet()) {
            MyString key = entry.getKey();
            MyString value = entry.getValue();
            valuesList.add((ValueString) value);
            System.out.println(key + " - " + value + " : key.equals(value)? " + key.equals(value));
            System.out.println("value.equals(value)? " + value.equals(value));
        }
        System.out.println("\nComparing different value objects:");
        for (int i = 0; i < valuesList.size(); i++) {
            for (int j = i + 1; j < valuesList.size(); j++) {
                System.out.println(valuesList.get(i) + ".equals(" + valuesList.get(j) + ")? " +
                        valuesList.get(i).equals(valuesList.get(j)));
            }
        }
        sc.close();
    }
}
class MyString {
    private String value;
    public MyString(String value) {
        this.value = value;
    }
    public String getValue() {
        return value;
    }
    @Override
    public String toString() {
        return value;
    }
    @Override
    public int hashCode() {
        return Objects.hash(value);
    }
}
class ValueString extends MyString {
    public ValueString(String value) {
        super(value);
    }
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof ValueString) {
            return this.getValue().equals(((ValueString)obj).getValue());
        }
        return false;
    }
}
