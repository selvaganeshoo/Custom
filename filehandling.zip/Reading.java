package filehandling;
import java.io.FileInputStream;
import java.io.IOException;
public class Reading {
    public static void main(String[] args) {
        FileInputStream f = null;
        try{
            f = new FileInputStream("Custom.java");
            int data;
            while((data = f.read())!=-1){
                System.out.print((char)data);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            try{
                if(f!=null){
                    f.close();
                }
            }
            catch(IOException e){
                e.printStackTrace();
            }
        }
    }
}