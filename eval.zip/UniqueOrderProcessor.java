package eval;
import java.lang.RuntimeException;
import java.util.HashMap;
public class UniqueOrderProcessor{
    private HashMap<String,String> a = new HashMap<>();
    private void put(String b,String c){
        if(a.containsKey(b)){
            throw new DuplicateOrderException("Order already found");
        }
        else{
            a.put(b,c); 
        }
    }
    @Override
    public String toString(){
        return a.toString();
    }
    public static void main(String[] args) throws Exception {
        UniqueOrderProcessor d = new UniqueOrderProcessor();
        d.put("1", "A");
        d.put("2", "B");
        d.put("3", "C");
        d.put("4", "D");
        d.put("5", "E");
        d.put("6", "F");
        d.put("7", "G");
        d.put("11", "H");
        d.put("12", "I");
        d.put("8", "J");
        d.put("1", "K");
        d.put("9", "L");
        d.put("10", "M");
        System.out.println(d);
    }
}
class DuplicateOrderException extends RuntimeException {
    public DuplicateOrderException(String message) {
        super(message);
    }
    public DuplicateOrderException(String message, Throwable cause) {
        super(message, cause);
    }
}

