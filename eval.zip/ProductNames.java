package eval;
import java.util.TreeSet;
public class ProductNames {
    private TreeSet<String> A = new TreeSet<>();
    private void add(String a){
        try{
            A.add(a);
        }
        catch(Exception e){
            System.out.println("Null value is skipped");
        }
    }
    public String toString(){
        return A.toString();
    }
    public static void main(String[] args) {
        ProductNames p = new ProductNames();
        p.add("start");
        p.add(null);
        p.add("end");
        System.out.println(p);
    }
}