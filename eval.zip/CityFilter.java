package eval;
import java.util.ArrayList;
import java.util.HashSet;
public class CityFilter {
   private HashSet<String> A = new HashSet<>();
   public String toString(){
    return A.toString();
   }
   private void add(String a){
    if(a == null || a==""){
        throw new EmptyLineException();
    }
    else if(A.contains(a)){
        A.remove(a);
    }
    else{
        A.add(a);
    }
   }
    private void total(){
        System.out.println(A.size());
    }
    public static void main(String[] args) {
        ArrayList<String> citynames = new ArrayList<>();
        citynames.add("Rjpm");
        citynames.add("Srivi");
        citynames.add("Mdu");
        citynames.add("Ten");
        citynames.add(null);
        citynames.add("Mdu");
        citynames.add("Ten");
        citynames.add("chen");
        System.out.println(citynames);
        CityFilter b = new CityFilter();
        b.add("Rjpm");
        b.add("Srivi");
        b.add("Mdu");
        b.add("Ten");
        b.add("Mdu");
        b.add("Ten");
        b.add("chen");
        b.add("Puliyangudi");
        b.total();
        System.out.println(b);
        b.add(null);
    }
}
class EmptyLineException extends RuntimeException{
    EmptyLineException(){
        System.out.println("This Line is empty");
    }
}
