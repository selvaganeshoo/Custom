package Exceptions.Basic;
public class ExNo2 {
    public static void main(String[] args) {
        String a = "123@abc";
        try{
            System.out.println(Integer.parseInt(a));
        }
        catch(NumberFormatException w){
            System.out.println(w);
            System.out.println("Cannot convert non-numeric to int");
        }
        finally{
            System.out.println("Program completed");
        }
    }
}
