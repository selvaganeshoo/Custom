package Exceptions.Basic;
public class ExNo3 {
    public static void main(String[] args) throws ArrayIndexOutOfBoundsException {
        int[] a = {1,2,3,4,5};
    try{
        System.out.println(a[5]);
        System.out.println(a[-1]);
    }
    catch(ArrayIndexOutOfBoundsException e ){
        System.err.println(e);
    }
    }
}
