package Exceptions.Basic;
import java.util.Scanner;
public class ExNo1 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int a = s.nextInt();
        int b = s.nextInt();
        try{
            System.out.println(a/b);
        }
        catch (ArithmeticException q){
            System.out.println("***************");
            System.out.println("Get Message: "+q.getMessage());
            System.out.println("***************");
            System.out.println("Cause: "+q.getCause());
            System.out.println("***************");
            System.out.println("print: "+q.toString());
            System.out.println("***************");
            System.out.println("Stacktrace: ");
            q.printStackTrace();
            System.out.println("***************");
            System.out.println("Get Stack Trace: "+q.getStackTrace());
            System.out.println("***************");
            System.out.println("Filllin stack trace: "+q.fillInStackTrace());
            System.out.println("***************");
            System.out.println(q);
            System.out.println("***************");
            System.out.println("CANNOT DIVIDE BY ZERO"); 
        } 
    }
}
