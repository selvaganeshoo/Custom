package exceptions.intermediate;

public class ExNo2 {
    public int check(int a){
        try{
            System.out.println("hello");
            return a*a;
        }
        catch(Exception e){
            System.out.println("hi");
        }
        finally{
            System.out.println("arg0");
        }
        return a;
    }
    public static void main(String[] args) {
        ExNo2 a = new ExNo2();
        System.out.println(a.check(5));
    }
}
