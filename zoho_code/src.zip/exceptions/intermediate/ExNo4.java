package exceptions.intermediate;
import java.io.*;
public class ExNo4 {
    public void reader(String path)throws IOException{
        FileReader a = new FileReader(path);
        a.close();
    }
    public static void main(String[] args){
        String a = "/home/workspace/Learning/src/exceptions/intermediate/ExNo1.java";
        ExNo4 b = new ExNo4();
        try{
            b.reader(a);
            System.out.println("File Readed");
        }
        catch(Exception e){
            System.out.println("File not found or can't read");
        }
    }
}
