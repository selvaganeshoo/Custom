package exceptions.intermediate;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ExNo5 {
    public static void main(String[] args) {
        try(FileReader a = new FileReader("/home/workspace/Learning/src/exceptions/intermediate/ExNo1.java")){System.out.println("File readed");}
        catch(Exception e) {
            System.out.println("File not readed");
        }
    }
}