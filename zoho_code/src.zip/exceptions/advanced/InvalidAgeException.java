package exceptions.advanced;
public class InvalidAgeException extends RuntimeException {
    private int age;
    public InvalidAgeException(int age){
        super("Exception Caught: Invalid age must be above 18: "+age);
        this.age = age;
    }
}
