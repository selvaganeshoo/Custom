import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
public class ArrayListDemo {
    public static void main(String[] args) {
        // ArrayList a = new ArrayList();
        // a.add(5);
        // a.add("hello");
        // a.toString();
        // a.add(null);
        // System.out.println(a);
        // System.out.println(a.remove(2));
        // a.remove((Object)5);
        // System.out.println(a);
        // Object[] b = new Object[26];
        String a = new String("ab");
        String b ="ab";
        System.out.println(a);
        System.out.println(b);
        System.out.println(a==b);
    }
}