
public class Generic <T>{
    T x;
    Generic(T x){
        this.x = x;
    }
    public T getValue(){
        return x;
    }
}
