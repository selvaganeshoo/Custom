package generic;
import java.util.Scanner;
public class Over {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a = sc.next();
        int player1 = 0;
        int player2 = 0;
        int extras = 0;
        boolean pos = false;
        for(int i=0;i<a.length();i++){
            int digit = a.charAt(i) - '0';
            if(a.charAt(i)=='w' || a.charAt(i)=='n'){
                extras++;
                continue;
            }
            if(digit>=0 && digit<=6){
                if(digit == 1 || digit == 3){
                pos = false;
            }
            else{
               pos = true; 
            }
            if(pos){
                player1+= digit;
            }
            else{
                player2+= digit;
            }
        }
        }
        System.out.println("player 1 score is: "+player1);
        System.out.println("player 2 score is: "+player2);
        System.out.println("Extras: "+extras);
    }
}