
import java.util.HashMap;
public class GenericChecker {
    public static void main(String[] args) {
    Generic<Integer> a = new Generic<>(10);
    Generic<Character> b = new Generic<Character>('x');
    Generic<Double> c = new Generic<Double>(24.21);
    Generic<String> d = new Generic<String>("hi!");
    Generic<Float> e = new Generic<Float>(2.0f);
    System.out.println(a.getValue());
    System.out.println(b.getValue());
    System.out.println(c.getValue());
    System.out.println(d.getValue());
    System.out.println(e.getValue());
    AnotherGeneric<String,Integer> g = new AnotherGeneric<>("Tom", 23);
    System.out.println(g.getvalue("a"));
    }
}