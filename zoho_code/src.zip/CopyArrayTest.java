import java.util.Arrays;
import java.util.Scanner;

public class CopyArrayTest {
    public static void main(String[] args) {
        testCopyArray();
    }

    public static void testCopyArray() {
        // Redirect input for testing
        String input = "5\n1\n2\n3\n4\n5\n";
        Scanner scanner = new Scanner(input);
        
        // Mock scanner usage from the main method
        System.out.println("enter size");
        int n = scanner.nextInt();
        int[] a = new int[n];
        int[] b = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.println("enter element " + (i + 1));
            a[i] = scanner.nextInt();
            b[i] = a[i];
        }

        // Test Case 1
        int[] expectedOutput = {1, 2, 3, 4, 5};
        if (Arrays.equals(b, expectedOutput)) {
            System.out.println("Test Passed: Copying array elements");
        } else {
            System.out.println("Test Failed: Expected " + Arrays.toString(expectedOutput) + " but got " + Arrays.toString(b));
        }
        
        scanner.close();
    }
}