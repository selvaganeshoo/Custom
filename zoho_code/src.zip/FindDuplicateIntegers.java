import java.util.Arrays;
import java.util.Scanner;
/**
 * Find Duplicate Integer Values
 * 
 * Write a Java program to find the duplicate values of an array of integer values.
 */
public class FindDuplicateIntegers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int arraysize = sc.nextInt();
        int[] array = new int[arraysize];
        int[] result = new int[arraysize];
        int index=0;
        for(int i=0;i<arraysize;i++){
            array[i] = sc.nextInt();
        }
        int temp = array[0];
        for(int i=0;i<arraysize-1;i++){
            for(int j=i+1;j<arraysize;j++){
                if(array[i]>array[j]){
                temp=array[i];
                array[i]=array[j];
                array[j]=temp;
                }
            }
        }
        for(int i=1;i<arraysize;i++){
            if(array[i-1]==array[i]){
                if(index==0||result[index-1]!=array[i]){
                    result[index++]=array[i-1];
                }
            }
        }
        for(int i=0;i<index;i++){
            System.out.print(result[i]+" ");
        }
    }
}