import java.util.*;
public class DiamondStarPattern {    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n=sc.nextInt();
        if(n%2==0)
        {
            System.out.println(" ");
        }
        int k=(n/2)+1;
        for(int i=1;i<=k;i++)
        {
            for(int j=i;j<k;j++)
            {
                System.out.print(" ");
            }
            for(int m=1;m<=2*i-1;m++)
            {
                System.out.print("*");
            }
            System.out.println();
        }
         for (int i = k-1; i >= 1; i--) {
            for (int j =k; j > i; j--) {
                System.out.print(" ");
            }
            for (int l = 1; l <= (2 * i - 1); l++) {
                System.out.print("*");
            }
            System.out.println();
        }
        sc.close();
    }
}