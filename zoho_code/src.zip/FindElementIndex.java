import java.util.Scanner;

/**
 * Find Array Element Index
 * 
 * Write a Java program to find the index of an array element.
 */

public class FindElementIndex {
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n=sc.nextInt();
        int[] a=new int[n];
        for(int i=0;i<n;i++)
        {
            System.out.println("enter element "+(i+1));
            a[i]=sc.nextInt();
        }
        int b=0;
        System.out.println("enter the search element");
        int s=sc.nextInt();
        for(int i=0;i<n;i++)
        {
            if(a[i]==s)
            {
                b=1;
                System.out.println("the index is "+i);
            }
        }
        if(b==0)
        {
            System.out.println("not found "+-1);
        }
        sc.close();
    }
} 