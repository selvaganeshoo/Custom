/**
 * Simple Number Checker
 * 
 * Write a Java program that checks if a given integer is zero, positive, or negative. The program should take an integer as input and print 'Zero' if the number is zero, 'Positive' if the number is greater than zero, or 'Negative' if it is less than zero.
 */
import java.util.Scanner;
public class SimpleNumberChecker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int integer = sc.nextInt();
        if(integer == 0){
            System.out.println("Zero");
        }
        else if(integer > 0){
            System.out.println("Positive");
        }
        else{
            System.out.println("Negative");
        }
    }
} 