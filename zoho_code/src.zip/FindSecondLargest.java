import java.util.Scanner;
public class FindSecondLargest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int[] array = new int[size];
        for(int i=0;i<size;i++){
            array[i] = sc.nextInt();
        }
        int largest = array[0];
        int secondlargest = array[0];
        for(int i=1;i<size;i++){
           if(array[i]>largest){
            secondlargest = largest;
            largest =array[i];
           }else if (array[i] > secondlargest && array[i] < largest) {
                secondlargest = array[i];  
            }
        }
        System.out.println(secondlargest);
    }
}