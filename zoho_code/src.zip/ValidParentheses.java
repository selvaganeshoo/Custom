import java.util.Scanner;
public class ValidParentheses {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char[] chars = sc.next().toCharArray();
        sc.close();
        char[] stack = new char[chars.length / 2 + 1];
        int top = -1;
        boolean valid = true;
        if (chars.length == 0) valid = false;
        for (char ch : chars) {
            switch (ch) {
                case '(':
                case '[':
                case '{':
                    if (++top >= stack.length) { valid = false; break; }
                    stack[top] = ch;
                    break;

                case ')':
                    if (top < 0 || stack[top--] != '(') valid = false;
                    break;

                case ']':
                    if (top < 0 || stack[top--] != '[') valid = false;
                    break;

                case '}':
                    if (top < 0 || stack[top--] != '{') valid = false;
                    break;

                default:
            }
            if (!valid) break;
        }
        if (top != -1) valid = false;
        System.out.println(valid);
    }
}
