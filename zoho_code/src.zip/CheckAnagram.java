import java.util.Scanner;

/**
 * Check Anagram
 * 
 * Write a Java program to check if two strings are anagrams.
 */
import java.util.Arrays;
public class CheckAnagram {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a=sc.nextLine();
        String b=sc.nextLine();
        int a1=a.length();
        int a2=b.length();
        if(a1!=a2){
            System.out.println(false);
        }
        char[] A = a.toCharArray();
        char[] B = b.toCharArray();
        Arrays.sort(A);
        Arrays.sort(B);
        System.out.println(Arrays.equals(A,B));
    }
} 