/**
 * Find Unique Triplets
 * 
 * Write a Java program to find all the unique triplets such that sum of all the three elements equal to a specified number.
 */
import java.util.Scanner;
public class FindUniqueTriplets {
    private static int[] sort(int[] arr){
        int small = Integer.MIN_VALUE;
        for(int i=0;i<arr.length-1;i++){
            for(int j=i+1;j<arr.length;j++){
                if(arr[i]>arr[j]){
                    small = arr[i];
                    arr[i] = arr[j];
                    arr[j] = small; 
                }
            }
        }
        return arr;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter size of an array: ");
        int n = sc.nextInt();
        int[] a = new int[n];
        for(int i=0;i<n;i++)
        {
            System.out.print("Enter the element: ");
            a[i]=sc.nextInt();
        }
        System.out.print("Enter the target: ");
        int t = sc.nextInt();
        sort(a);
        for(int i=0;i<n-2;i++){
            for(int j=i+1;j<n-1;j++){
                if(a[i]==a[j]){
                    continue;
                }
                for(int k=j+1;k<n;k++){
                    if(a[j]==a[k]){
                        continue;
                    }
                    if(a[i]+a[j]+a[k] == t){
                        System.out.print("[ "+a[i]+", "+a[j]+", "+a[k]+" ] ");
                    }
                }
            }
        }
    }
}