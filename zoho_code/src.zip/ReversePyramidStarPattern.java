import java.util.*;
public class ReversePyramidStarPattern {    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a=sc.nextInt();
        for(int i=a;i>=1;i--)
        {
            
            for(int k=1;k<=a-i;k++)
            {
                System.out.print(" ");
            }
            for(int j=0;j<(i*2)-1;j++)
            {
                System.out.print("*");
            }
            
            System.out.println();
        }
        sc.close();
    }
}