import java.util.Arrays;
import java.util.Scanner;
public class FindCommonThreeArrays {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int  n = sc.nextInt();
        int[] array1 = new int[n];
        int[] array2 = new int[n];
        int[] array3 = new int[n];
        int[] result = new int[n];
        int l=0;
        for(int i=0;i<n;i++){
            array1[i]=sc.nextInt();
        }
        for(int i=0;i<n;i++){
            array2[i]=sc.nextInt();
        }
        for(int i=0;i<n;i++){
            array3[i]=sc.nextInt();
        }
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                for(int k=0;k<n;k++){
                    if(array1[i]==array2[j]&&array2[j]==array3[k]){
                        result[l++]=array1[i];
                    }
                }
            }
        }
        System.out.println(Arrays.toString(result));
    }
} 