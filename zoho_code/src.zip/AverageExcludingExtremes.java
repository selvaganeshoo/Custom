import java.util.Scanner;
public class AverageExcludingExtremes {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        int min=0;
        int max=0;
        int sum=0;
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
            if(a[i]>=max){
                max=a[i];
            }
            if(a[i]<=min){
                min=a[i];
            }
        }
        for(int i=0;i<n;i++){
            if(a[i]!=max&&a[i]!=min){
                sum+=a[i];
            }
        }
        double result = (double)sum/(n-2);
        System.out.println(result);
    }
} 