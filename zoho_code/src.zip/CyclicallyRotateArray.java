/**
 * Cyclically Rotate Array
 * 
 * Write a Java program to cyclically rotate a given array clockwise by one.
 */
import java.util.Scanner;
public class CyclicallyRotateArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int[] arr = new int[size];
        for(int i=0;i<size;i++){
            arr[i] = sc.nextInt();
        }
        for(int i=0;i<size;i++){
            if(i==0){
                System.out.print(arr[size-1]);
            }
            else{
            System.out.print(" "+arr[i-1]);
            }
        }
    }
}