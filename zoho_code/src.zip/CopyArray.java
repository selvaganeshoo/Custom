import java.util.Scanner;
import java.util.Arrays;



public class CopyArray{
    
    
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size");
        int n=sc.nextInt();
        int[] a=new int[n];
        int[] b=new int[n];
        for(int i=0;i<n;i++)
        {
            System.out.println("enter element "+(i+1));
            a[i]=sc.nextInt();
            b[i]=a[i];
        }
        System.out.println(Arrays.toString(b));
        sc.close();
    }
}