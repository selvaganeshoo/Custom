package comparable;
import java.util.Comparator;
import java.util.Stack;
public interface Comparable<T> extends Comparator {
    public int compareTo(T o);
}

