package comparable;
import java.util.Collections;
class Test implements Comparable<Test>{
    private String name;
    private int rating;
    private int year;
    Test(String name, int rating, int year){
        this.name = name;
        this.rating = rating;
        this.year = year;
    }
    public int compareTo(Test o){
        return this.year-o.year;
    }
    public String getName(){
        return this.name;
    }
    public int getRating(){
        return this.rating;
    }
    public int getYear(){
        return this.year;
    }
}