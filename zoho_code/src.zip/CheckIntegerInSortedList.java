/**
 * Check Integer in Sorted List
 * 
 * Suppose we had a list of n integers sorted in ascending order. How quickly could we check if a given integer is in the list?
 */
import java.util.Scanner;

public class CheckIntegerInSortedList {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of list: ");
        int size = sc.nextInt();
        int[] arr = new int[size];
        System.out.print("Enter " + size + " integers in ascending order: ");
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        System.out.println("Enter target integer:");
        int target = sc.nextInt();
        int start = 0;
        int end = size - 1;
        boolean found = false;
        while (start <= end) {
            int mid = start + (end - start) / 2;
            if (arr[mid] == target) {
                found = true;
                break;
            } else if (arr[mid] < target) {
                start = mid + 1;
            } else {
                end = mid - 1;
            }
        }
        System.out.println(found);
    }
}
