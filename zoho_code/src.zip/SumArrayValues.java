import java.util.Scanner;
import java.util.Arrays;
public class SumArrayValues extends Object {
    
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of array");
        int n=sc.nextInt();
        int sum=0;
        int[] a=new int[n];
        for(int i=0;i<n;i++)
        {
            System.out.println("Enter element "+(i+1));
            a[i]=sc.nextInt();
            sum+=a[i];
        }
        System.out.println("the sum is "+sum);
        System.out.println(a);
        sc.close();
    }
}