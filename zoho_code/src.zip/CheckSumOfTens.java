import java.util.Scanner;
public class CheckSumOfTens {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        int sum=0;
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
            if(a[i]==10){
                sum+=a[i];
            }
        }
        sc.close();
        if(sum==30){
            System.out.println(true);
        }
        else{
            System.err.println(false);
        }
    }
}