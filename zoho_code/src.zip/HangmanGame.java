import java.util.Scanner;

public class HangmanGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Task 1: Create an array of words that can be used in the game.
        // Choose words related to a specific theme or category (e.g., animals, fruits).

        // Task 2: Randomly select a word from the array and store it as the secret
        // word.

        int maxAttempts = 6; // Set the maximum number of incorrect guesses

        StringBuilder guessedWord = new StringBuilder(); // This will store the player's progress
        String secretWord = ""; // The word to guess
        int incorrectGuesses = 0;

        // Task 3: Initialize guessedWord with underscores to represent the unguessed
        // letters.

        System.out.println("Welcome to Hangman!");

        while (incorrectGuesses < maxAttempts) {
            System.out.println("Word: " + guessedWord.toString());
            System.out.println("Incorrect guesses: " + incorrectGuesses);

            // Task 4: Get a letter guess from the player.

            // Task 5: Check if the guessed letter is in the secret word.
            // If it is, update guessedWord to reveal the positions of the correctly guessed
            // letters.
            // If it isn't, increment incorrectGuesses.

            // Task 6: Check if the player has guessed the entire word. If they have, they
            // win.

            // Task 7: Add a condition to end the game if the player has used up all their
            // attempts.
        }

        // Task 8: Display a message to the player indicating whether they won or lost.

        // Task 9: Add an option for the player to play again if they want.

        scanner.close();
    }
}
