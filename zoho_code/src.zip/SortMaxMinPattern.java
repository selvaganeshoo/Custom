/**
 * Sort Array in Max-Min Pattern
 * 
 * Write a Java program to sort an array of positive integers where the first element should be maximum, second should be minimum, third should be second maximum, fourth should be second minimum and so on.
 */
import java.util.Scanner;
public class SortMaxMinPattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array: ");
        int size = sc.nextInt();
        int arr[] = new int[size];
        for(int i=0;i<size;i++){
            arr[i] = sc.nextInt();
        }
        
    }
}