/**
 * Parenthesis Validation
 * 
 * Write a function that, given a sentence and the position of an opening parenthesis, finds the corresponding closing parenthesis.
 */

public class ParenthesisValidation {
    
    // TODO: Implement your solution here
    
    public static void main(String[] args) {
        // Test your solution here
    }
}