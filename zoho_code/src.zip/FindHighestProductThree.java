/*
 * Find Highest Product of Three Integers
 * 
 * Given a list of integers, find the highest product you can get from three of the integers.
 */
 import java.util.Arrays;
import java.util.Scanner;
public class FindHighestProductThree {    
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the size: ");
        int size = s.nextInt();
        int[] arr = new int[size];
        int largest = Integer.MIN_VALUE;
        for(int i=0;i<size;i++){
            System.out.print("Enter the Element: ");
            arr[i] = s.nextInt();
        }
        Arrays.sort(arr);
        int a = arr[size-1]*arr[size-2]*arr[size-3];
        int b = arr[0]*arr[1]*arr[size-1];
        System.out.println(Math.max(a, b));
    }
}