/**
 * Separate Zeros and Ones Random Order
 * 
 * Write a Java program to separate 0s on left side and 1s on right side of an array of 0s and 1s in random order.
 */
import java.util.Scanner;
public class SeparateZerosOnesRandom {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int[] array = new int[size];
        for(int i=0;i<size;i++){
            if(array[i] == 0||array[i] == 1){
                array[i] = sc.nextInt();
            }
            else{
                i--;
            }
        }
        int left = 0;
        int right = size-1;
        while(left<right){
            while(left < right && array[left]==0) left++;
            while(left < right && array[right]==1) right--;
            if(left<right){
                int swapper = array[left];
                array[left] = array[right];
                array[right] = swapper;
                left++;
                right--;
            }
        }
        for(int i=0;i<size;i++){
            System.out.print(array[i]+" ");
        }
    }
} 