/**
 * Find Common Elements Between Arrays
 * 
 * Write a Java program to find the common elements between two arrays of string values.
 */
import java.util.Scanner;
public class FindCommonStrings {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String[] a = new String[n];
        String[] b = new String[n];
        for(int i=0;i<n;i++){
            a[i]=sc.next();
        }
        for(int i=0;i<n;i++){
            b[i]=sc.next();
        }
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                if(a[i].equals(b[j])){
                    System.out.print(a[i]+" ");
                    break;
                }
            }
        }
    }
}