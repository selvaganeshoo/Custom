/**
 * Find Pairs with Sum
 * 
 * Write a Java program to find all pairs of elements in an array whose sum is equal to a specified number.
 */
import java.util.Arrays;
import java.util.Scanner;
public class FindPairsWithSum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter size of array: ");
        int size = sc.nextInt();
        int[] array = new int[size];
        for(int i=0;i<size;i++){
            System.out.print("Enter the "+(i+1)+"'s element: ");
            array[i] = sc.nextInt();
        }
        System.out.print("Enter the target: ");
        int target = sc.nextInt();
        int[][] pairs = findpairs(array, target);
        System.out.print("[ ");
        for (int i = 0; i < pairs.length; i++) {
            System.out.print("[ " + pairs[i][0] + ", " + pairs[i][1] + " ] ");
        }
        System.out.println("]");
    }
    private static int[][] findpairs(int[] array,int target){
        int size = array.length;
        int[][] pairs = new int[size*(size-1)/2][2];
        int count = 0;
        for(int i=0;i<size-1;i++){
            for(int j=i+1;j<size;j++){
                if(array[i]+array[j]==target){
                    int a = Math.min(array[i],array[j]);
                    int b = Math.max(array[i],array[j]);
                    boolean exist = false;
                    for(int k=0;k<count;k++){
                        if(pairs[k][0]==a&&pairs[k][1]==b){
                            exist = true;
                            break;
                        }
                    }
                    if(!exist){
                        pairs[count][0]=a;
                        pairs[count][1]=b;
                        count++;
                    }
                }
            }
        }
        int[][] result = new int[count][2];
        for(int i=0;i<count;i++){
            for(int j=0;j<2;j++){
                result[i][0]=pairs[i][0];
                result[i][1]=pairs[i][1];
            }
            System.out.println();
        }
        return result;
    }
}