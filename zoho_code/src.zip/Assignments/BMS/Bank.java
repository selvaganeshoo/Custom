package Assignments.BMS;
public interface Bank {
    public void createAccount();
    public void changename();
}