package Assignments.HundredProblems;
public class student {
     student(){
        System.out.println("Parent");
    }
}
