package Assignments.HundredProblems;
import java.util.Scanner;
public class FindDuplicateValues {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n=s.nextInt();
        int[] a = new int[n];
        boolean[] b = new boolean[n];
        boolean duplicateFound = false;
        for(int i=0;i<n;i++){
            a[i]=s.nextInt();
        }
        for(int i=0;i<n;i++){
            if(b[a[i]]&&!duplicateFound){
                System.out.println("Duplicate element is: "+a[i]);
                duplicateFound = true;
            }
            else{
                b[a[i]]=true;
            }
        }   
    }
}