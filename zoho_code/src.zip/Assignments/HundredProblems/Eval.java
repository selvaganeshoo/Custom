package Assignments.HundredProblems;
public class Eval{
    int sum(int a, int b){
        return a+b;
    }
    public static void main(String[] ag) {
        Eval a = new Eval();
        System.out.println(a.sum(5, 7));
    }
}