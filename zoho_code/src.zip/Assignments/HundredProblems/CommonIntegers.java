package Assignments.HundredProblems;
import java.util.Scanner;
public class CommonIntegers{
    static int l=9;
    
    {
        int a=5;
        System.out.println(a);
        a++;
        l++;
        System.out.println(l);  
    }
    CommonIntegers(){
        int b=5;
        System.out.println(b);
        b++;
    }
    @Override
    public String toString(){
        return String.valueOf(l);
    }
    public static void main(String[] args){
        CommonIntegers a =new CommonIntegers();
        System.out.println(a);
        CommonIntegers b= new CommonIntegers();
        System.out.println(b);
        System.out.println(a);

    }
}
