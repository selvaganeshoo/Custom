package Assignments.Patterns;
import java.util.Scanner;
public class Crisscross {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter String: ");
        String a=sc.next();
        int l=a.length();
        int n=l;
        if(l%2==0)
        {
            n+=1;
        }
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                if(l%2==0)
                {
                    if(i==l/2&&j==l/2)
                    {
                        System.out.print("\u00B7 ");
                    }
                    else
                    {
                        System.out.print("* ");
                    }
                }
                else{
                    System.out.print("* ");
                }
            }
            System.out.println();
        }
    }
}
