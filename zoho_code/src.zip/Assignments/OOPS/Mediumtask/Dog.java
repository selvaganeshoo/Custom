package Assignments.OOPS.Mediumtask;

public class Dog extends Animal {
   private String breed;
   private String color;

    public Dog(String name, int age, String species, String breed, String color) {
        super(name, age, species);
        this.breed = breed;
        this.color = color;
    }
    @Override
    public void displayInfo() {
        super.displayInfo(); 
        System.out.println("Breed: " + breed);
        System.out.println("Color: " + color);
    }
}