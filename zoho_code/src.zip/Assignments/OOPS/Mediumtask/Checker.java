package Assignments.OOPS.Mediumtask;

import Assignments.OOPS.Inheritance.Animal;

public class Checker {
    public static void main(String[] args) {
        Animal a = new Animal("Tom", 10, "Dog");
        Dog b = new Dog("Tom", 10, "Dog", "Kanni", "Brown");
        a.displayInfo();
        b.displayInfo();
    }
}
