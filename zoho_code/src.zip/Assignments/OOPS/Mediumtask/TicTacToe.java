package Assignments.OOPS.Mediumtask;
import java.util.Scanner;
public class TicTacToe {
    private static char[][] a;
    private static int n;
    private static int r;
    private static int c;
    public static boolean Check(int r,int c){
        if(a[r][c]=='\u0000'){
            return true;
        }
        else{
            return false;
        }
    }
    public static void display(){
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                System.out.print(" "+a[i][j]);
            }
            System.out.println();
        }
    }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the size of the board (eg: 3 for 3X3 and 7 for 7X7): ");
        n = s.nextInt();
        a=new char[n][n];
        int moves=n*n;
        for(int i=1;i<=moves;i++){
            while(i%2!=0){
                System.out.print("Player One turn: ");
                r = s.nextInt();
                System.out.print("enter position: ");
                c = s.nextInt();
                if(Check(r,c)){
                    a[r][c] = 'X';
                    display();
                    break;
                }
                else{
                System.out.println("Location Already Marked");
                display();
                }
            }
            while(i%2==0){
                System.out.print("Player Two turn: ");
                r = s.nextInt();
                System.out.print("enter position: ");
                c = s.nextInt();
                if(Check(r,c)){
                    a[r][c] = 'O';
                    display();
                    break;
                }
                else{
                System.out.println("Location Already Marked");
                display();
                }
            }
        }
        
    }
}
