package Assignments.OOPS.Easy;
public class Easychecker {
    public static void main(String[] args) {
        Easy a = new Easy();
        int b[]=new int[]{1,2,3,4,5,6,7,8,9,10};
        System.out.println(a.calculateAverage(b));
        System.out.println(a.isPalindrome("tanat"));
        System.out.println(a.isPalindrome("fallout"));
        System.out.println(a.fact(10));
        System.out.println(a.max(b));
        System.out.println(a.reverseString("M:I"));
        System.out.println(a.reverseString("TENET"));
    }
}
