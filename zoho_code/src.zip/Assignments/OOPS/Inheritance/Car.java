package Assignments.OOPS.Inheritance;

public class Car extends Vehicle {
private String color;
private int numdoors;
public Car(String make, String model, int year, String color, int numdoors)
{
    super(make, model, year);
    this.color=color;
    this.numdoors=numdoors;
}
    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Colour: "+color);
        System.out.println("Number of Doors: "+numdoors);
    }
}
