package Assignments.OOPS.Evaluation;
public class Checker2{
    Checker2(int arr){
        System.out.println(arr);
    }
    Checker2(){
        System.out.println("hello");
    }
}