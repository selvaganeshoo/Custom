package Assignments.OOPS.Evaluation;
public class Checker extends Checker2 {
    Checker(int d){
        System.out.println(d);
    }
    Checker(){
        super(19);
    }
    public static void main(String[] args) {
        Checker s = new Checker();
        System.out.println(s);
    }
}