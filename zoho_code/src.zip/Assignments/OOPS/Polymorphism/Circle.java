package Assignments.OOPS.Polymorphism;

public class Circle extends Shape {
    @Override
    public void draw()
    {
        System.out.println("Drawing a Circle");
    }
}
