package Assignments.OOPS.Polymorphism;
public class Shape {
    public void draw()
    {
        System.out.println("Drawing a shape");
    }
}
