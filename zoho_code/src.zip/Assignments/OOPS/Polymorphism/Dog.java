package Assignments.OOPS.Polymorphism;

public class Dog extends Animal {
    @Override
    public void speak()
    {
        System.out.println("Dog says woof!");
    }
}
