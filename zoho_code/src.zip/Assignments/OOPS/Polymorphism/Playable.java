package Assignments.OOPS.Polymorphism;

public interface Playable {
    public void play();
}
