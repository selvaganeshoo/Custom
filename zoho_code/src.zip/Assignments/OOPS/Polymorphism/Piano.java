package Assignments.OOPS.Polymorphism;

public class Piano implements Playable {
     public void play()
    {
        System.out.println("Piano : Implemented from playable");
    }
}
