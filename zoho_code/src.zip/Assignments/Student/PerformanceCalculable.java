package Assignments.Student;
interface PerformanceCalculable {
    double calculateAverage();
}