package Assignments.Student;
class Student extends SchoolMember implements PerformanceCalculable {
    private String grade;
    private int[] marks;
    private int markCount;

    public Student(String name, int age, String grade, int maxMarks) {
        super(name, age);
        this.grade = grade;
        this.marks = new int[maxMarks];
        this.markCount = 0;
    }

    public String getGrade() { return grade; }

    // Overloading example: add one mark or multiple marks
    public void addMark(int mark) {
        if (markCount < marks.length) {
            marks[markCount++] = mark;
        }
    }
    public void addMark(int mark1, int mark2, int mark3) {
        addMark(mark1);
        addMark(mark2);
        addMark(mark3);
    }

    @Override
    public void showRole() {
        System.out.println(getName() + " is a Student in grade " + grade);
    }

    @Override
    public double calculateAverage() {
        if (markCount == 0) return 0;
        int total = 0;
        for (int i = 0; i < markCount; i++) {
            total += marks[i];
        }
        return total / (double) markCount;
    }
}

