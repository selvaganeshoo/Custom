package Assignments.Student;
class Teacher extends SchoolMember {
    private String subject;

    public Teacher(String name, int age, String subject) {
        super(name, age);
        this.subject = subject;
    }

    @Override
    public void showRole() {
        System.out.println(getName() + " teaches " + subject);
    }
}
