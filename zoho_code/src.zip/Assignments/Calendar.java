package Assignments;
import java.util.Scanner;
public class Calendar 
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        
        System.out.print("Enter day (1-31): ");
        int date = sc.nextInt();
        System.out.print("Enter month (1-12): ");
        int month = sc.nextInt();
        System.out.print("Enter year (e.g. 2025): ");
        int year = sc.nextInt();

        if(date>=1&&date<=31&&month>=1&&month<=12&&year>=0)
        {

        if (month < 3) {
            month += 12;
            year -= 1;
        }

        int K = year % 100;     
        int J = year / 100;     

        
        int h = (date + (13 * (month + 1)) / 5 + K + K/4 + J/4 + 5 * J) % 7;

        
        String[] days = {"Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};

        
        System.out.println("Day of the week: " + days[h]);
        }
        else{
            System.out.println("incorret input");
        }
    }
}
