package Assignments.String;
public class Checker extends Object {
    public static void main(String[] args) {
        String a = new String();
        Strings c = new Strings("HI");
        Strings d = new Strings("HI HELLO!!");
        Strings str2 = new Strings("Learn Java");
        Strings str3 = new Strings("Learn ");
        System.out.println(str1);
    }
}
