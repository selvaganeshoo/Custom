package Assignments.String;
public class Stringbuilder{
    public char string[];
    public int length;
    public Stringbuilder(char[] string){
        length=string.length;
        this.string=new char[length];
        for(int i=0;i<length;i++){
            this.string[i]=string[i];
        }
    }
    public char[] toCharArray() {
        char[] copy = new char[length];
        for (int i = 0; i < length; i++) {
            copy[i] = string[i];
        }
        return copy;
    }
    public char charAt(int index) {
        return string[index];
    }
}
