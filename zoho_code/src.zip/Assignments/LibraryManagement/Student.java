package Assignments.LibraryManagement;
class Student extends User {
    Student(String name) { super(name); }
    @Override
    void showRole() { System.out.println("Student: " + name); }
}
