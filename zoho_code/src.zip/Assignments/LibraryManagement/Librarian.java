package Assignments.LibraryManagement;
class Librarian extends User {
    Librarian(String name) { super(name); }
    @Override
    void showRole() { System.out.println("Librarian: " + name); }
}
