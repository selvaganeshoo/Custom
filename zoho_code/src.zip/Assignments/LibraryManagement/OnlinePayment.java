package Assignments.LibraryManagement;
class OnlinePayment implements Payment {
    @Override
    public void pay(double amount) {
        System.out.println("Paid " + amount + " online");
    }
}
