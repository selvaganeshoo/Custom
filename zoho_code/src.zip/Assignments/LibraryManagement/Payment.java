package Assignments.LibraryManagement;
interface Payment {
    void pay(double amount);
    default void printReceipt(double amount) {
        System.out.println("Receipt: Paid " + amount);
    }
    static void rules() {
        System.out.println("Payments are non-refundable!");
    }
}
