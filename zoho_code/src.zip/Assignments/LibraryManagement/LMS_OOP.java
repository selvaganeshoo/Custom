package Assignments.LibraryManagement;
import java.util.Scanner;
public class LMS_OOP {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Library lib = Library.getInstance();  // Singleton
        User u1 = new Student("Alice");
        User u2 = new Librarian("Bob");
        u1.showRole();
        u2.showRole();
        int choice;
        do {
            System.out.println("\n---Sheikh's  Library---");
            System.out.println("1. Add Book");
            System.out.println("2. View Books");
            System.out.println("3. Issue Book");
            System.out.println("4. Return Book");
            System.out.println("5. Pay Fine");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    sc.nextLine();
                    System.out.print("Enter title: ");
                    String title = sc.nextLine();
                    System.out.print("Enter author: ");
                    String author = sc.nextLine();
                    lib.addBook(title, author);
                    break;
                case 2:
                    lib.viewBooks();
                    break;
                case 3:
                    System.out.print("Enter book ID to issue: ");
                    int id1 = sc.nextInt();
                    lib.issueBook(id1);
                    break;
                case 4:
                    System.out.print("Enter book ID to return: ");
                    int id2 = sc.nextInt();
                    lib.returnBook(id2);
                    break;
                case 5:
                    Payment p = new OnlinePayment();
                    p.pay(50);
                    p.printReceipt(50);
                    Payment.rules();
                    break;
                case 6:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 6);
        sc.close();
    }
}