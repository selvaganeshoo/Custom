package Assignments.BankManagementSystem;

interface Transaction {
    void deposit(double amount);
    void withdraw(double amount);
}
