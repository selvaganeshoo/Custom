package Assignments.BankManagementSystem;

interface Reportable {
    void displayDetails();
}
