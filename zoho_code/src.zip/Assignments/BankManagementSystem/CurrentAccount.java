package Assignments.BankManagementSystem;

public class CurrentAccount extends Account {
      public CurrentAccount(String accountNumber, String holderName, double balance) {
        super(accountNumber, holderName, balance);
    }
    @Override
    public String getAccountType() {
        return "Current";
    }
}
