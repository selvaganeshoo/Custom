package Assignments.SnakeAndLadderGame;
class Cell {
    private int num;
    Cell(int num){
        this.num=num;
    }
    public int getnumber(){
        return num;
    }
    @Override
    public String toString(){
        return String.valueOf(num);
    }
}