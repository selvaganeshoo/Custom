package Assignments.SnakeAndLadderGame;
class Snake {
    private int head;
    private int tail;
    Snake(int head,int tail){
        this.head=head;
        this.tail=tail;
    }
    public int snakehead(){
        return head;
    }
    public int snaketail(){
        return tail;
    }
}