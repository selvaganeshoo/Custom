package Assignments.SnakeAndLadderGame;
class Players{
    private String name;
    private int position = 1;
    Players(String n){
        name=n;
    }
    public void increment(int i){
        position+=i;
    }
    public void decrement(int d){
        position-=d;
    }
    public int getposition(){
        return position;
    }
    public void setposition(int pos){
        position = pos;
    }
    @Override
    public String toString(){
        return String.valueOf(name);
    }
}