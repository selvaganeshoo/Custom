package Assignments.SnakeAndLadderGame;
class Ladder {
    private int head;
    private int tail;
    Ladder(int h,int t){
        head=h;
        tail=t;
    }
    public int ladderhead(){
        return head;
    }
    public int laddertail(){
        return tail;
    }
}