package Assignments.SnakeAndLadderGame;
import java.util.Scanner;
import java.util.Random;
public class Board {
    public static void main(String[] args) {
        int maxpos=1;
        Scanner sc = new Scanner(System.in);
        Random r = new Random();
        System.out.print("Enter the number of cells in board: ");
        int n = sc.nextInt();
        int s = (int)Math.sqrt(n);
        if(s*s<n)s++;
        Cell[][] board = new Cell[s][s];
        int number=1;
        for(int i=s-1;i>=0;i--){
            if((i%2)!=0){
                for(int j=0;j<s;j++){
                    if(number<=n){
                    board[i][j] = new Cell(number++);
                    }
                    else{
                        board[i][j] = null;
                    }
                }
            }
            else{
                for(int j=s-1;j>=0;j--){
                    if(number<=n){
                        board[i][j] = new Cell(number++);
                    }
                    else{
                        board[i][j] = null;
                    }
                }
            }
        }
        System.out.print("Enter number of Players: ");
        int p = sc.nextInt();
        Players[] player = new Players[p];
        for(int i=0;i<p;i++){
            System.out.print("Enter Player name: ");
            player[i] = new Players(sc.next());
        }
        System.out.println("Enter number of snakes");
        int snake =  sc.nextInt();
        Snake[] a = new Snake[snake];
        for(int i=0;i<snake;i++){
            System.out.println("Enter head and tail position of snake");
            int h = sc.nextInt();
            int t = sc.nextInt();
            if(h>t){
                a[i]= new Snake(h, t);
            }
            else{
                System.out.println("Enter valid position");
                i--;
            }
        }
        for(int i=0;i<s;i++){
            for(int j=0;j<s;j++){
                
            }
        }
        System.out.println("Enter number of laders");
        int l = sc.nextInt();
        Ladder[] b = new Ladder[l];
        for(int i=0;i<l;i++){
            System.out.println("Enter head and tail position of Ladder");
            int h = sc.nextInt();
            int t = sc.nextInt();
            if(h>t){
                b[i]= new Ladder(h, t);
            }
            else{
                System.out.println("Enter valid position");
                i--;
            }
        }
        System.out.println("______Snake and Ladder Board______");
        for(int i=0;i<s;i++){
            for(int j=0;j<s;j++){
                for(int k=0;k<snake;k++){
                if(board[i][j].getnumber()==a[k].snakehead()){
                    System.out.print("(S"+a[k].snakehead()+")\t");
                    break;
                }
                else if(board[i][j].getnumber()==a[k].snaketail()){
                    System.out.print("(S"+a[k].snaketail()+")\t");
                    break;
                }
                }
                for(int k=0;k<l;k++){
                if(board[i][j].getnumber()==b[k].ladderhead()){
                    System.out.print("(S"+b[k].ladderhead()+")\t");
                    break;
                }
                else if(board[i][j].getnumber()==b[k].laddertail()){
                    System.out.print("(S"+b[k].laddertail()+")\t");
                    break;
                }
                }
                System.out.print(board[i][j]+"\t");
            }
            System.out.println();
        }
        while(maxpos<=n){
            for(int i=0;i<player.length;i++){
                System.out.println(player[i]+"'s Turn");
                sc.nextLine();
                System.out.println("dice rolling");
                int c = r.nextInt(6)+1;
                player[i].increment(c);
                if(maxpos<=player[i].getposition()){
                    maxpos=player[i].getposition();
                }
                if(a[i].snakehead()==player[i].getposition()){
                    player[i].setposition(a[i].snaketail());
                }
                if(b[i].laddertail()==player[i].getposition()){
                    player[i].setposition(b[i].ladderhead());
                }
            }
        }
    }
}