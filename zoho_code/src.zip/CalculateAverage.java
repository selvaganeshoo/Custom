import java.util.Scanner;

/**
 * Calculate Array Average
 * 
 * Write a Java program to calculate the average value of array elements.
 */

public class CalculateAverage {
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of the array");
        int n=sc.nextInt();
        System.out.println("Enter array elements");
        int[] a=new int[n];
        int sum=0;
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
            sum+=a[i];
        }
        System.out.println("The average is "+(sum/n));
        sc.close();

    }
} 