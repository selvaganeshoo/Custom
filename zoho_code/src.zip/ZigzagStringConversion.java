import java.util.Arrays;
import java.util.Scanner;

/**
 * Zigzag String Conversion
 * 
 * Given a string and a number of lines k, print the string in zigzag form. In zigzag, characters are printed out diagonally from top left to bottom right until reaching the kth line, then back up to top right, and so on.
 */

public class ZigzagStringConversion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter The String: ");
        String s = sc.next();
        System.out.print("Enter size of Bandwidth: ");
        int line = sc.nextInt();
        sc.close();
        int end = s.length();
        int e = end;
        char[][] result = new char[line][end];
        int index = 0;
        int indexi = 0;
        int indexj = 0;
        while(e!=0){
            if(index<end){
            if(indexi==line){
                for(int i=0;i<line&& index<end;i++){
                result[--indexi][indexj++] = s.charAt(index);
                e--;
            }
            }
            }
            if(index < end){
            for(int i=0;i<line&& index<end;i++){
                result[indexi++][indexj++] = s.charAt(index);
                index++;
                e--;
            }
            }
        }
        for(int i=0;i<line;i++){
            for(int j=0;j<end;j++){
                if(result[i][j]!='\u0000'){
                System.out.print(result[i][j]);
                }else{
                    System.out.print(' ');
                }

            }
            System.out.println();
        }
    }
}