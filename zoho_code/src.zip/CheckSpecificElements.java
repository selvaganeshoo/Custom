import java.util.Scanner;
public class CheckSpecificElements {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int found65=0;
        int found77=0;
        int n=sc.nextInt();
        int[] a = new int[n];
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
            if(a[i]==65){
                found65=a[i];
            }
            if(a[i]==77){
                found77=a[i];
            }
            if(found65!=0&&found77!=0){
            break;
        }

        }
        if(found65!=0&&found77!=0){
            System.out.println(true);
        }
        else{
            System.out.println(false);
        }
    }
}