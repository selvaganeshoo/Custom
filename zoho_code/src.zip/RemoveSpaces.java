import java.util.*;
public class RemoveSpaces {
    
    
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a=sc.nextLine();
        System.out.println(a.replaceAll("\\s",""));
        sc.close();
    }
}