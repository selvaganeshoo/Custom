/**
 * Find Missing Number
 * 
 * Write a Java program to find a missing number in an array.
 */
import java.util.Scanner;
public class FindMissingNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        for(int i=0;i<n;i++){
            a[i] = sc.nextInt();
        }
        int check = a[0];
        for(int i=0;i<n;i++){
            if(check!=a[i]){
                System.out.print(check+" ");
                i--;
            }
            check++;
        }
    }
}