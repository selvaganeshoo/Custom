import java.util.Arrays;
import java.util.Scanner;

/**
 * Sort Numeric and String Arrays
 * 
 * Write a Java program to sort a numeric array and a string array.
 */

public class SortArrays {
    
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of numeric array");
        int n=sc.nextInt();
        int[] a=new int[n];
        for(int i=0;i<n;i++)
        {
            System.out.println("enter element "+(i+1));
            a[i]=sc.nextInt();
        }
        Arrays.sort(a);
        System.out.println("enter size of string array");
        int k=sc.nextInt();
        sc.nextLine();
        String[] b=new String[k];
        for(int i=0;i<k;i++)
        {
            System.out.print("enter element "+(i+1));
            b[i]=sc.nextLine();
            System.out.println();
        }
        Arrays.sort(b);
        System.out.println(Arrays.toString(a));
        System.out.println(Arrays.toString(b));
        sc.close();
    }
} 