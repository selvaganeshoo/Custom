/**
 * Find N-th Perfect Number
 * 
 * A number is considered perfect if its digits sum up to exactly 10. Given a positive integer n, return the n-th perfect number.
 */
import java.util.Scanner;
public class FindNthPerfectNumber {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the elment: ");
        int n=s.nextInt();
        int m = n;
        int k = (n - 10)*-1;
        int l = (m*10)+k;
        System.out.print(l);
    }
}