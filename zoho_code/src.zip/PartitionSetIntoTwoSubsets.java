/**
 * Partition Set into Two Subsets
 * 
 * Given a set of integers, return whether the set can be partitioned into two subsets whose sums are the same.
 */
import java.util.AbstractList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.Arrays;
import java.util.PriorityQueue;
public class PartitionSetIntoTwoSubsets {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int s = sc.nextInt();
        int sum1 = 0;
        int a[] = new int[s];
        for(int i=0;i<s;i++){
            a[i] = sc.nextInt();
            sum1+=a[i];
        }
        int sum2 = sum1/2;
        int r = 0;
        int re = 0;
        Arrays.sort(a);
        int l=0;
        int ri=s-1;
        int index =0;
        while(l<ri){
            if(r+(a[l]+a[ri])<=sum2){
                r+=(a[l]+a[ri]);
            }
            else if(re+(a[l]+a[ri])<=sum2){
            re+= (a[l]+a[ri]);
            }
           if(r==re){
            l++;
            ri--;
           }
           else if(r<re){
                l++;
           }
           else{
            ri--;
           }
        }
        System.out.println(r);
        System.out.println(re);
        System.out.println(r==re);
    }
}