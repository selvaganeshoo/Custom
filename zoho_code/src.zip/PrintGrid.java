import java.util.Scanner;

/**
 * Print Grid Pattern
 * 
 * Write a Java program to print a 10x10 grid of dashes.
 */

public class PrintGrid {
    
   
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the rows and colums");
        int s=sc.nextInt();
        int[][] a=new int[s][s];
        for(int i=0;i<s;i++)
        {
            for(int j=0;j<s;j++)
            {
                System.out.print("-" );
            }
            System.out.println();
        }
        sc.close();
    }
} 