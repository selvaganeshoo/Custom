/**
 * Segregate Zeros and Ones
 * 
 * Write a Java program to segregate all 0s on left side and all 1s on right side of a given array of 0s and 1s.
 */
import java.util.Arrays;
import java.util.Scanner;
public class SegregateZerosAndOnes {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int[] array = new int[size];
        for(int i=0;i<size;i++){
            array[i] = sc.nextInt();
        }
        int swapper = array[0];
        for(int i=0;i<size;i++){
            for(int j=i+1;j<size;j++){
                if(array[i]>array[j]){
                    swapper = array[i];
                    array[i] = array[j];
                    array[j] = swapper;
                }
            }
        }
        System.out.println(Arrays.toString(array));
    }
}