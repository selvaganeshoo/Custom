package list;
public class MyLinkedListTest{
	public static void main(String[] args){
	MyLinkedList a = new MyLinkedList();
	System.out.println(a);
	a.add(1);
	System.out.println(a);
	a.add("hello");
	System.out.println(a);
	a.add(4);
	System.out.println(a);
	a.add("hi");
	System.out.println(a);
	a.add(32);
	System.out.println(a);
	}
}
