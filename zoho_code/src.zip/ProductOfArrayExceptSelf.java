/**
 * Product of Array Except Self
 * 
 * Given an array of integers, return a new array such that each element at index i of the new array is the product of all the numbers in the original array except the one at i. Solve it without using division and in O(n) time.
 */
import java.util.Arrays;
import java.util.Scanner;
public class ProductOfArrayExceptSelf {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int s = sc.nextInt();
        int a[] = new int[s];
        int r[] = new int[s];
        int index = 0;
        for(int i=0;i<s;i++){
            a[i] = sc.nextInt();
        }
        while(index<s){
            int temp = 1;
            for(int i=0;i<s;i++){
                if(i!=index){
                    temp*=a[i];
                }
            }
            r[index++] = temp;
        }
        System.out.println(Arrays.toString(r));
    }
}