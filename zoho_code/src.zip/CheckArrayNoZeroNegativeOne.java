import java.util.Scanner;
public class CheckArrayNoZeroNegativeOne {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        boolean b = true;
        for(int i=0;i<n;i++){
            a[i] = sc.nextInt();
            if(a[i]<=0){
                b = false;
                sc.close();
                break;
            }
        }
        sc.close();
        System.out.println(b);
    }
} 