import java.util.*;

public class StringCompressionTest {
    public static void main(String[] args) {
        testCompression("aabcccccaaa", "a2b1c5a3");
        testCompression("abcd", "a1b1c1d1");
        testCompression("aabbcc", "a2b2c2");
        testCompression("a", "a1");
        testCompression("", "");
    }

    private static void testCompression(String input, String expectedOutput) {
        Scanner sc = new Scanner(input);
        StringBuilder a = new StringBuilder();
        String b = sc.next();
        int c = 1;

        for (int i = 1; i < b.length(); i++) {
            if (b.charAt(i) == b.charAt(i - 1)) {
                c++;
            } else {
                a.append(b.charAt(i - 1)).append(c);
                c = 1;
            }
        }

        if (b.length() > 0) {
            a.append(b.charAt(b.length() - 1)).append(c);
        }

        String result = a.toString();
        if (result.equals(expectedOutput)) {
            System.out.println("Test Passed: Compress(\"" + input + "\") == \"" + expectedOutput + "\"");
        } else {
            System.out.println("Test Failed: Compress(\"" + input + "\") == \"" + result + "\"; expected \"" + expectedOutput + "\"");
        }
        
        sc.close();
    }
}