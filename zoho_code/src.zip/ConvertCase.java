import java.util.*;
public class ConvertCase {
    
    
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a=sc.nextLine();
        char[] b=a.toCharArray();
        if(b[0]>='A'&&b[0]<='Z')
        {
            char[] c=new char[b.length];
            int j=0;
            for(int i=0;i<b.length;i++)
            {
                c[j]=Character.toLowerCase(b[i]);
                j++;
            }
            System.out.println(new String(c));
        }
        else{
            char[] c=new char[b.length];
            int j=0;
            for(int i=0;i<b.length;i++)
            {
                c[j]=Character.toUpperCase(b[i]);
                j++;
            }
            System.out.println(new String(c));
        }
        sc.close();
    }
}