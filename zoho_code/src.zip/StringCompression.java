import java.util.*;
public class StringCompression {
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner (System.in);
        StringBuilder a=new StringBuilder();
        String b=sc.next();
        int c=1;
        for(int i=1;i<b.length();i++)
        {
                if(b.charAt(i)==b.charAt(i-1))
                {
                    c++;
                }
                else{
                    a.append(b.charAt(i-1)).append(c);
                    c=1;
                }
        }
        if(b.length()>0)
        {
            a.append(b.charAt(b.length()-1)).append(c);
        }
        System.out.println(a.toString());
        sc.close();
    }
}