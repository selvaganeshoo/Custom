/**
 * Find Largest Product of Three
 * 
 * Given a list of integers, return the largest product that can be made by multiplying any three integers.
 */
import java.util.Arrays;
import java.util.Scanner;
public class FindLargestProductOfThree {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int size = sc.nextInt();
        int arr[] = new int[size];
        for(int i=0;i<size;i++){
            arr[i] = sc.nextInt();
        }
        Arrays.sort(arr);
        int a = arr[0]*arr[1]*arr[size-1];
        int b = arr[size-1]*arr[size-2]*arr[size-3];
        System.out.println(Math.max(a, b));
    }
}