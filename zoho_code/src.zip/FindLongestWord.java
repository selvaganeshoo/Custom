import java.util.*;
public class FindLongestWord {
    
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String a= sc.nextLine();
        String[] b=a.split("\\s");
        String d="";
        for (String c : b) 
        {
            if(c.length()>d.length())
            {
                d=c;
            }    
        }
        System.out.println(d);
        
        sc.close();
    }
}