/**
 * Find Rotation Count
 * 
 * Write a Java program to find the rotation count in a given rotated sorted array of integers.
 */
import java.util.Scanner;
public class FindRotationCount {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter size: ");
        int n = sc.nextInt();
        int[] a = new int[n];
        int smallest = Integer.MAX_VALUE;
        int smalli = -1;
        for(int i=0;i<n;i++){
            System.out.print("Enter element number "+(i+1)+": ");
            a[i] = sc.nextInt();
            if(a[i]<smallest){
                smallest = a[i];
                smalli = i;
            }
        }
        System.out.println(smalli);
    }
}