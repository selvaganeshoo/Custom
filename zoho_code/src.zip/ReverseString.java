import java.util.*;

public class ReverseString {
    
    
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a =sc.nextLine();
        StringBuilder b = new StringBuilder(a);
        System.out.println(b.reverse());
        sc.close();
    }
} 