/**
 * Convert ArrayList to Array
 * 
 * Write a Java program to convert an ArrayList to an array.
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class ArrayListToArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        ArrayList <Integer> arraylist = new ArrayList<>();
        for(int i=0;i<size;i++){
            arraylist.add(sc.nextInt());
        }
        int[] array = new int[size];
        for(int i=0;i<size;i++){
            array[i] = arraylist.get(i);
        }
        System.out.println(Arrays.toString(array));
    }
}