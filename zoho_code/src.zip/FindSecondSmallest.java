/*
 * Find Second Smallest Element
 * 
 * Write a Java program to find the second smallest element in an array.
 */
import java.util.Scanner;
public class FindSecondSmallest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        for(int i=0;i<n;i++){
            a[i] = sc.nextInt();
        }
        int smallest = a[0];
        int secondsmallest = a[0];
        for(int i=1;i<n;i++){
           if(a[i]<smallest){
            secondsmallest = smallest;
            smallest =a[i];
           }else if (a[i] < secondsmallest && a[i] != smallest) {
                secondsmallest = a[i];  
            }
        }
        System.out.println(secondsmallest);
    }
}