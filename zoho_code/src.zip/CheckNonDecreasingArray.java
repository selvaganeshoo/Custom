/**
 * Check Non-Decreasing Array
 * 
 * Given an array of integers, write a function to determine whether the array could become non-decreasing by modifying at most 1 element.
 */
import java.util.Scanner;
public class CheckNonDecreasingArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean b = false;
        System.out.print("Enter the size of array: ");
        int s = sc.nextInt();
        int a[] = new int[s]; 
        for(int i=0;i<s;i++){
            System.out.print("Enter the element number "+i+": ");
            a[i] = sc.nextInt();
        }
        for(int i=0;i<s;i++){
            for(int j=i+1;j<s;j++){
                if(a[i]-a[j]<0){
                    b = true;
                }
                break;
            }
        }
        if(b){
            System.out.println("true");
        }else{
            System.out.println("false");
        }
    }
}