import java.util.Scanner;

/**
 * Check Array Contains Value
 * 
 * Write a Java program to test if an array contains a specific value.
 */

public class CheckArrayContains {
    
    
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int b=0;
        System.out.println("enter the size of array");
        int n=sc.nextInt();
        int[] a=new int[n];
        for(int i=0;i<n;i++)
        {
            System.out.println("Enter the element "+(i+1));
            a[i]=sc.nextInt();
        }
        System.out.println("Enter the search element");
        int s=sc.nextInt();
        for(int i=0;i<n;i++)
        {
            if(a[i]==s)
            {
                b=1;
                break;
            }
        }
        if(b==1)
        {
            System.out.println(true);
        }
        else{
            System.out.println(false);
        }
        sc.close();
    }
} 