/**
 * Convert Array to ArrayList
 * 
 * Write a Java program to convert an array to ArrayList.
 */
import java.util.ArrayList;
import java.util.Scanner;
public class ArrayToArrayList {
    
    // TODO: Implement your solution here
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int[] array = new int[size];
        for(int i=0;i<size;i++){
            array[i] = sc.nextInt();
        }
        ArrayList <Integer> arraylist = new ArrayList<>();
        for(int i=0;i<size;i++){
            arraylist.add(i,array[i]);
        }
        for(int i : arraylist){
            System.out.print(i+" ");
        }
    }
}