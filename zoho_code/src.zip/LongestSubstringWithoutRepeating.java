import java.util.Scanner;
public class LongestSubstringWithoutRepeating {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a = sc.next();

        int[] lastSeen = new int[256]; 
        for (int i = 0; i < 256; i++) lastSeen[i] = -1; 

        int start = 0; 
        int maxLen = 0;
        int startIndexOfMax = 0; 

        for (int end = 0; end < a.length(); end++) {
            char c = a.charAt(end);


            if (lastSeen[c] >= start) {
                start = lastSeen[c] + 1;
            }

            lastSeen[c] = end; 

            
            if (end - start + 1 > maxLen) {
                maxLen = end - start + 1;
                startIndexOfMax = start;
            }
        }

        String maxSubstring = a.substring(startIndexOfMax, startIndexOfMax + maxLen);
        System.out.println(maxLen);    

    }
}
 