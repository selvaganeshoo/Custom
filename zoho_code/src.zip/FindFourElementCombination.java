/**
 * Find Combination of Four Elements
 * 
 * Write a Java program to find all combination of four elements of a given array whose sum is equal to a given value.
 */
import java.util.Arrays;
import java.util.Scanner;
public class FindFourElementCombination{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter size of arr: ");
        int size = sc.nextInt();
        int[] arr = new int[size];
        for(int i=0;i<size;i++){
            System.out.print("Enter a element: ");
            arr[i] = sc.nextInt();
        }
        System.out.print("Enter the target: ");
        int target = sc.nextInt();
        Arrays.sort(arr);
        for(int i=0;i<size-3;i++){
            for(int j=i+1;j<size-2;j++){
                for(int k=j+1;k<size-1;k++){
                    for(int l=k+1;l<size;l++){
                        if(arr[i]+arr[j]+arr[k]+arr[l] == target){
                            System.out.println("["+arr[i]+", "+arr[j]+", "+arr[k]+", "+arr[l]+"]");
                        }
                    }
                }
            }
        }
    }
}