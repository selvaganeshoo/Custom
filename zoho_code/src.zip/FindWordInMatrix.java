/**
 * Find Word in Matrix
 * 
 * Given a 2D matrix of characters and a target word, write a function that returns whether the word can be found in the matrix by going left-to-right, or up-to-down.
 */

public class FindWordInMatrix {
    public static void main(String[] args) {
        
    }
}