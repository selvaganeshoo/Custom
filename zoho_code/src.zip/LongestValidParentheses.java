/**
 * Longest Valid Parentheses
 * 
 * Write a Java program to find the length of the longest valid parentheses substring.
 */
import java.util.Scanner;
public class LongestValidParentheses {   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a = sc.next();
        char[] s = new char[a.length()];
        int top = -1; 
        int count =0;
        for(int i=0;i<a.length();i++){
            if(a.charAt(i)=='('){
                s[++top] = a.charAt(i);
            }
            else{
            if(top == -1){
                
            }
            else{
            char o = s[top--];
            if( a.charAt(i)==')'&& o=='('){
                count+=2;
            }
            }
            }
        }
        System.out.println(count);
    }
}