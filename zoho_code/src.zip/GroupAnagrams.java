/**
 * Group Anagrams
 * 
 * Write a Java program to group strings that are anagrams together.
 */
import java.util.Scanner;
public class GroupAnagrams {
    public static void checker(String[] args,int N){
        char[] a = new char[N];
        for(int i=0;i<N;i++){

        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of elements");
        int N=sc.nextInt();
        String[] a=new String[N];
        for(int i=0;i<N;i++){
            System.out.print("Enter String number: "+(i+1));
            a[i] = sc.next();
        }
        checker(a, N);
    }
}