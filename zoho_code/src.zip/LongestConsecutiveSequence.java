/**
 * Find Longest Consecutive Sequence
 * 
 * Write a Java program to find the length of the longest consecutive elements sequence from a given unsorted array of integers.
 */
import java.util.Arrays;
import java.util.Scanner;
public class LongestConsecutiveSequence {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter size of an array: ");
        int n = s.nextInt();
        int largestconsecutive = 1;
        int currentconsecutive = 1;
        int[] a = new int[n];
        if(n==0){
            largestconsecutive = 0;
        }
        for(int i=0;i<n;i++)
        {
            System.out.print("Enter the element: ");
            a[i]=s.nextInt();
        }
        Arrays.sort(a);
        for(int i=1;i<n;i++){
            if(a[i]-a[i-1]==0){
                continue;
            }
            else if(a[i]-a[i-1]==1){
                currentconsecutive++;
            }
            else{
                largestconsecutive= Math.max(largestconsecutive,currentconsecutive);
                currentconsecutive = 1;
            }
        }
        largestconsecutive = Math.max(largestconsecutive,currentconsecutive);
        System.out.println(largestconsecutive);
    }
}