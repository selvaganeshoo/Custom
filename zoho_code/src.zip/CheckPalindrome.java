import java.util.*;

/**
 * Check Palindrome
 * 
 * Write a Java program to check if a string is a palindrome.
 */

public class CheckPalindrome {
    
    
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a=sc.next();
        StringBuilder b = new StringBuilder(a);
        if (a.equals(b.reverse().toString()))
        {
            System.out.println(true);
        }
        else{
            System.out.println(false);
        }
        sc.close();
    }
}