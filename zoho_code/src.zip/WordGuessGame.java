import java.util.Scanner;
import java.util.Random;

public class WordGuessGame {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        String[] words = { "apple", "banana", "cherry", "grape", "orange", "strawberry", "watermelon" };

        // Task 1: Randomly select a word from the "words" array and store it as the
        // secret word.

        int maxIncorrectGuesses = 6; // Set the maximum number of incorrect guesses
        int incorrectGuesses = 0;

        StringBuilder guessedWord = new StringBuilder(); // This will store the player's progress

        // Task 2: Initialize guessedWord with underscores to represent the unguessed
        // letters.

        System.out.println("Welcome to Word Guess!");
        System.out.println("Try to guess the word, one letter at a time.");
        System.out.println("You have " + maxIncorrectGuesses + " incorrect guesses allowed.");

        while (incorrectGuesses < maxIncorrectGuesses) {
            System.out.println("Word: " + guessedWord.toString());
            System.out.println("Incorrect guesses: " + incorrectGuesses);

            // Task 3: Get a letter guess from the player.

            // Task 4: Check if the guessed letter is in the secret word.
            // If it is, update guessedWord to reveal the positions of the correctly guessed
            // letters.
            // If it isn't, increment incorrectGuesses.

            // Task 5: Check if the player has guessed the entire word. If they have, they
            // win.
        }

        // Task 6: Display a message to the player indicating whether they won or lost.

        // Task 7: Add an option for the player to play again if they want.

        scanner.close();
    }
}
