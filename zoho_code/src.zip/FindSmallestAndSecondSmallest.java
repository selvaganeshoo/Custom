import java.util.*;

public class FindSmallestAndSecondSmallest {
    
   
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter size");
        int n=sc.nextInt();
        if(n>2)
        {
        int[] a= new int[n];
        for(int i=0;i<n;i++)
        {
            System.out.println("enter element "+(i+1));
            a[i]=sc.nextInt();
        }
        Arrays.sort(a);
        System.out.println("smallest is "+a[0]+" second smallest is "+a[1]);
        }
        else{
            System.out.println("Error or handling for less than two elements");
        }
        sc.close();
    }
}