/**
 * Find Sum of Two Elements
 * 
 * Write a Java program to find the sum of the two elements of a given array which is equal to a given integer.
 */
import java.util.Scanner;
public class FindSumOfTwoElements {
    public static void main(String[] args) {
       Scanner s = new Scanner(System.in);
       System.out.print("enter size of array: ");
       int n = s.nextInt();
       int[] a = new int[n];
       for(int i=0;i<n;i++){
        System.out.print("enter "+(i+1)+"'s element: ");
        a[i]=s.nextInt();
       }
       System.out.print("enter the target: ");
       int t=s.nextInt();
       s.close();
       boolean found=false;
       int r=0;
       int c=0;
       for(int i=0;i<n-1;i++){
        for(int j=i+1;j<n;j++){
            if(t == a[i] + a[j]){
                r = i;
                c = j;
                found = true;
                break;
            }
        }
        if(found){
            break;
        }
       }
       r+=1;
       c+=1;
       if(found){
            System.out.println(r+" "+c);
       }
       else{
        System.out.println("not found!");
       }
    }
} 