import java.util.Arrays;
import java.util.Scanner;
public class FindSumCloseToZero {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int sizeofarray = sc.nextInt();
        int[] result = new int[2];
        int[] array = new int[sizeofarray];
        for(int i=0;i<sizeofarray;i++){
            array[i] = sc.nextInt();
        }
        int minimumnumber=array[0]+array[1];
        sc.close();
        for(int i=0;i<sizeofarray-1;i++){
            for(int j=i+1;j<sizeofarray;j++){
                int sum=array[i]+array[j];
                if(minimumnumber*minimumnumber>sum*sum){
                    minimumnumber = sum;
                    result[0] = array[i];
                    result[1] = array[j];                }
            }
        }
        System.out.println(Arrays.toString(result));
    }
}