import java.util.Scanner;
import java.util.Arrays;
/**
 * Print Matrix in Clockwise Spiral
 * 
 * Given a N by M matrix of numbers, print out the matrix in a clockwise spiral.
 */
public class PrintMatrixClockwiseSpiral {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of rows: ");
        int rows = sc.nextInt();
        System.out.print("Enter number of columns: ");
        int columns = sc.nextInt();
        int matrix[][] = new int[rows][columns];
        int result[] = new int[rows*columns];
        for(int i=0;i<rows;i++){
            for(int j=0;j<columns;j++){
                System.out.print("Enter a element for the position: "+i+", "+j+": ");
                matrix[i][j] = sc.nextInt();
            }
        }
        sc.close();
        int left = 0;
        int top = 0;
        int right = columns-1;
        int bottom = rows-1;
        int index = 0;
        int end = rows*columns;
        while(index < end){
            for(int i=left;i<=right;i++){
                result[index] = matrix[top][i];
                index++;
            }
            top++;
            for(int i = top; i <= bottom; i++){
                result[index] = matrix[i][right];
                index++;
            }
            right--;
            if(top <= bottom){
            for(int i = right; i >= left; i--){
                result[index] = matrix[bottom][i];
                index++;
            }
            bottom--;
            }
            if(left <= right){
            for(int i= bottom; i>= top; i--){
                result[index] = matrix[i][left];
                index++;
            }
            left++;
            }
        }
        System.out.println(Arrays.toString(result));
    }
}