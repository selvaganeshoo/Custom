import java.util.*;
public class FindSubstring {
    
    
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter String");
        String a=sc.nextLine();
        System.out.println("enter substring to check");
        String b=sc.next();
        System.out.println(a.contains(b));
        sc.close();
    }
}