import java.util.*;
public class FirstNonRepeatingChar {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    String a=sc.next();
    int[] f=new int[300];
    for(int i=0;i<a.length();i++)
    {
        f[a.charAt(i)]++;
    }
    boolean found=false;
    for(int i=0;i<a.length();i++)
    {
        if(f[a.charAt(i)]==1)
        {
            System.out.println(a.charAt(i));
            found = true;
            break;
        }
    }
    if(!found)
    {
        System.out.println("no repeating chars found");
    }
    sc.close();
    }
}