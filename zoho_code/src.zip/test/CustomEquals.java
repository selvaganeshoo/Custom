package test;
import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class CustomEquals {
    public static void main(String[] args) {
        Scanner sc =  new Scanner(System.in);
        HashMap<MyString, MyString> map = new HashMap<>();
        System.out.print("Enter Number of entries: ");
        int n = sc.nextInt();
        sc.nextLine();
        for(int i=0;i<n;i++){
            System.out.print("Enter Key: ");
            String key = sc.nextLine();
            System.out.print("Enter Value: ");
            String value = sc.nextLine();
            MyString k = new MyString(key);
            MyString v = new MyString(value);
            map.put(k,v);
            System.out.println(map);
        }
        ArrayList<MyString> values = new ArrayList<>();
        for(Map.Entry<MyString,MyString> entry: map.entrySet()){
            MyString key =  entry.getKey();
            MyString value = entry.getValue();
            values.add(value);
            System.out.println(key+" - "+value+": "+key.equals(value));
        }
        System.out.println("\nComparing different value objects:");
        for (int i = 0; i < values.size(); i++) {
            for (int j = i + 1; j < values.size(); j++) {
                System.out.println(values.get(i) + ".equals(" + values.get(j) + ")? " +
                        values.get(i).equals(values.get(j)));
            }
        }
        sc.close();
    }
}
class MyString {
    private String value;

    public MyString(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        MyString other = (MyString) obj;

        
        if (this == other) {
            return false;
        }

        
        return this.value.equals(other.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }

    @Override
    public String toString() {
        return value;
    }
}

