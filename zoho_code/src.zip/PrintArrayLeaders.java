import java.util.Arrays;
import java.util.Scanner;
public class PrintArrayLeaders {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int a[] = new int[n];
        for(int i=0;i<n;i++){
            a[i] = sc.nextInt();
        }
        int max=a[n-1];
        int[] b = new int[n];
        int k=0;
        for(int i=n-2;i>=0;i--){
            if(a[i]>max){
                max=a[i];
                b[k++]=a[i];
            }
        }
        for(int i=k-1;i>=0;i--){
            System.out.print(b[i]+" ");
        }
        System.out.print(a[n-1]+" ");
    }
}