/**
 * Count Possible Triangles
 * 
 * Write a Java program to count the number of possible triangles from a given unsorted array of positive integers.
 */
import java.util.Arrays;
import java.util.Scanner;
public class CountPossibleTriangles { 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of array: ");
        int size = sc.nextInt();
        int result = 0;
        int[] a = new int[size];
        for(int i=0;i<size;i++){
            System.out.print("Enter the sides: ");
            a[i] = sc.nextInt();
        }
        Arrays.sort(a);
        int index = 0;
       for(int i=0;i<size-2;i++){
        for(int j=i+1;j<size-1;j++){
            for(int k=j+1;k<size;k++){
                if(a[i]+a[j]>a[k]&&a[j]+a[k]>a[i]&&a[i]+a[k]>a[j]){
                    result++;
                }
            }
        }
       }
        System.out.println(result);
    }
} 