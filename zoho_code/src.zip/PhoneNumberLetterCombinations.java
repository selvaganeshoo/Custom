/**
 * Phone Number Letter Combinations
 * 
 * Given a mapping of digits to letters (as in a phone number), and a digit string, return all possible letters the number could represent.
 */

public class PhoneNumberLetterCombinations {
    public static void main(String[] args) {
        
    }
}