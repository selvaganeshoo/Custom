import java.util.Scanner;
public class LongestCommonPrefix {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n=sc.nextInt();
        if(n==0){
            System.out.println("");
        }
        String[] a = new String[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.next();
        }
        if (n== 1) {
            System.out.println(a[0]);
            return;
        }
        String temp="";
        for(int i=0;i<a[0].length();i++)
        {
            for(int j=1;j<n;j++)
            {
                if(a[i].length()>a[j].length())
                {
                    temp=a[i];
                    a[i]=a[j];
                    a[j]=temp;
                }
            }
        }
        String prefix = a[0];
        for (int i = 0; i < a[0].length(); i++) {
            for (int j = 1; j < n; j++) {
            if (i >= a[j].length() || a[j].charAt(i) != prefix.charAt(i)) {
                System.out.println(prefix.substring(0, i));
                return; 
            }
            }
        }
        System.out.println(prefix); 

    }
}