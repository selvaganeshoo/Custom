/**
 * Left Rotate Array
 * 
 * A left rotation operation on an array of size shifts each of the array's elements unit to the left. For example, if 2 left rotations are performed on [1,2,3,4,5] array, then the array would become [3,4,5,1,2].
 */
import java.util.Scanner;
public class LeftRotateArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of array: ");
        int size = sc.nextInt();
        int[] arr = new int[size];
        for(int i=0;i<size;i++){
            System.out.print("Enter the element: ");
            arr[i] = sc.nextInt();
        }
        System.out.print("Enter number of rotation: ");
        int rotation = sc.nextInt();
        int i=0;
        int k=0;
        while(k<size){
            if(rotation<size){
                System.out.print(arr[rotation++]+" ");
            }
            else{
                System.out.print(arr[i]+" ");
                i++;
            }
            k++;
        }
    }
}