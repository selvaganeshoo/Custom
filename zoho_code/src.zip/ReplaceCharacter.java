import java.util.*;
public class ReplaceCharacter {
    
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a=sc.nextLine();
        char b=sc.next().charAt(0);
        char c=sc.next().charAt(0);
        System.out.println(a.replaceAll(String.valueOf(b),String.valueOf(c)));
        sc.close();
    }
}