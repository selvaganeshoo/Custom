/**
 * Check Pair with Specified Sum
 * 
 * Write a Java program to check whether there is a pair with a specified sum of a given sorted and rotated array.
 */
import java.util.Scanner;
public class CheckPairWithSum {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the size: ");
        int n = s.nextInt();
        int[] a = new int[n];
        for(int i=0;i<n;i++){
            System.out.print("Enter "+(i+1)+"th element: ");
            a[i] = s.nextInt();
        }
        System.out.print("Enter the target: ");
        int t = s.nextInt();
        boolean result = false;
        for(int i=0;i<n-1;i++){
            for(int j=i+1;j<n;j++){
                if(a[i]+a[j]==t){
                    result = true;
                    break;
                }
            }
        }
        System.out.println(result);
    }
}