/**
 * String to Integer
 * 
 * Write a Java program to convert a string to an integer (atoi).
 */
import java.util.Scanner;
public class StringToInteger {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a = sc.nextLine();
        int m = 0;
        int sign = 1; 
        int i = 0;

        
        if (a.length() > 0 && (a.charAt(0) == '-' || a.charAt(0) == '+')) {
            if (a.charAt(0) == '-') {
                sign = -1;
            }
            i++;
        }

        
        for (; i < a.length(); i++) {
            char c = a.charAt(i);
            if (c >= '0' && c <= '9') {
                m = m * 10 + (c - '0');
            }
           
        }

        m = m * sign;
        System.out.println(m);
    }
}
 