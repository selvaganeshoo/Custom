/**
 * Create Anti-Diagonals Array
 * 
 * Write a Java program to create an array of its anti-diagonals from a given square matrix.
 */
import java.util.Scanner;
public class CreateAntiDiagonals {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of rows: ");
        int row = sc.nextInt();
        int[][] matrix = new int[row][row];
        int[][] r = new int[(row*2)-1][row];
        for(int i=0;i<row;i++){
            for(int j=0;j<row;j++){
                System.out.print("Enter the element: "+i+","+j+": ");
                matrix[i][j] = sc.nextInt();
                r[i+j][i]= matrix[i][j];
            }
        }
        for(int i=0;i<(row*2)-1;i++){
            for(int j=0;j<row;j++){
                if(r[i][j]!=0){
                    System.out.print(r[i][j]+" ");
                }
            }
            System.out.println();
        }
    }
}