import java.util.Arrays;
import java.util.Scanner;

/**
 * Remove Array Element
 * 
 * Write a Java program to remove a specific element from an array.
 */

public class RemoveArrayElement {
    
    
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size");
        int n=sc.nextInt();
        int[] a=new int[n];
        for(int i=0;i<n;i++)
        {
            System.out.println("enter element "+(i+1));
            a[i]=sc.nextInt();
        }
        System.out.println("enter remove element");
        int s=sc.nextInt();
        int c=0;
        for(int i=0;i<n;i++)
        {
            if(a[i]!=s)
            {
                c++;
            }
        }
        int j=0;
        int[] b=new int[c];
        for(int i=0;i<n;i++)
        {
            if(a[i]!=s)
            {
               b[j]=a[i];
               j++; 
            }
        }
        System.out.println(Arrays.toString(b));
        sc.close();
    }
}