import java.util.Scanner;
import java.util.Arrays;

/**
 * Find Max and Min Values
 * 
 * Write a Java program to find the maximum and minimum value of an array.
 */

public class FindMaxMin {
    
    
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size");
        int n=sc.nextInt();
        if(n>=0)
        {
        int[] a=new int[n];
        for(int i=0;i<n;i++)
        {
            System.out.println("enter the elments "+(1+i));
            a[i]=sc.nextInt();
        }
        Arrays.sort(a);
        int k=(a.length)-1;
        System.out.println("min is "+a[0]+" max is "+a[k]);
        }
        else{
            System.out.println("No output, program requires array elements");
        }
        sc.close();
    }
}