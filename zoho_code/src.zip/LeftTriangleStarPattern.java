import java.util.Scanner;

public class LeftTriangleStarPattern 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        int n=sc.nextInt();
        int i,j;
        for(i=0;i<n;i++)
        {
            for(j=1;j<n-i;j++)
            {
                System.out.print(" ");
            }
            for(int k=n;k>=j;k--)
            {
                System.out.print("*");
            }
            System.out.println();
        }
        sc.close();
    }
}