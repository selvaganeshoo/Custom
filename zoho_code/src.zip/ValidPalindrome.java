import java.util.Scanner;
public class ValidPalindrome {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a = sc.nextLine();
        sc.close();
        int left = 0;
        int right = a.length() - 1;

        while (left < right) {
            char l = a.charAt(left);
            char r = a.charAt(right);
            if (!((l >= 'A' && l <= 'Z') || (l >= 'a' && l <= 'z') || (l >= '0' && l <= '9'))) {
                left++;
                continue;
            }

            if (!((r >= 'A' && r <= 'Z') || (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9'))) {
                right--;
                continue;
            }

            if (l >= 'A' && l <= 'Z') {
                l = (char)(l + 32);
            }

            if (r >= 'A' && r <= 'Z') {
                r = (char)(r + 32);
            }

            if (l != r) {
                System.out.println(false);
                return;
            }

            left++;
            right--;
        }

        System.out.println(true);
    }
}
 