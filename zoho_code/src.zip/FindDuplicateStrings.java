/**
 * Find Duplicate String Values
 * 
 * Write a Java program to find the duplicate values of an array of string values.
 */
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;
public class FindDuplicateStrings {
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       int size = sc.nextInt();
       String[] array = new String[size];
       String[] result = new String[size];
       for(int i=0;i<size;i++){
            array[i] = sc.next();
       }
       String temp="";
       for(int i=0;i<size-1;i++){
        for(int j=i+1;j<size;j++){
            if(array[i].compareTo(array[j]) > 0){
                temp=array[i];
                array[i]=array[j];
                array[j]=temp;
            }
        }
       }
       int index=0;
       for(int i=1;i<size;i++){
        if(array[i-1].equals(array[i])){
            if(index==0||!result[index-1].equals(array[i])){
                result[index++]=array[i-1];
            }
        }
       }
       for(int i=0;i<index;i++){
        System.out.print(result[i]+" ");
       }
    }
}