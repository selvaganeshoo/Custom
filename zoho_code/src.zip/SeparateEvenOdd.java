/**
 * Separate Even and Odd Numbers
 * 
 * Write a Java program to separate even and odd numbers of an array of integers. Put all even numbers first, and then odd numbers.
 */
import java.util.Scanner;
public class SeparateEvenOdd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int[] arr =new int[size];
        int[] result = new int[size];
        int even = 0;
        for(int i=0;i<size;i++){
            arr[i] = sc.nextInt();
            if(arr[i]%2==0){
                even++;
            }
        }
        int oddi = even;
        int eveni=0;
        for(int i=0;i<size;i++){
            if(arr[i]%2==0){
                result[eveni++] = arr[i]; 
            }
            else{
                result[oddi++] = arr[i];
            }
        }
        for(int i=0;i<size;i++){
            System.out.print(result[i]+" ");
        }
    }
}