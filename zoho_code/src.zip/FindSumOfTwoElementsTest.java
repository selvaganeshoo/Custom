public class FindSumOfTwoElementsTest {
    public static void main(String[] args) {
        
        // Test Case 1: Standard case
        testFindSum(new int[]{1, 2, 4, 5, 6}, 6, true, 1, 3);
        
        // Test Case 2: Target not possible
        testFindSum(new int[]{1, 2, 3, 9}, 20, false, -1, -1);
        
        // Test Case 3: Negative numbers included
        testFindSum(new int[]{-1, 0, 1, 2}, 1, true, 1, 4);
        
        // Test Case 4: Multiple pairs possible
        testFindSum(new int[]{1, 3, 2, 4, 3}, 6, true, 2, 4);
        
        // Test Case 5: All elements are the same
        testFindSum(new int[]{3, 3, 3, 3}, 6, true, 1, 2);
        
        // Test Case 6: Array with single element
        testFindSum(new int[]{10}, 10, false, -1, -1);

    }
    private static void testFindSum(int[] array, int target, boolean expectedFound, int expectedIndex1, int expectedIndex2) {
        boolean found = false;
        int n = array.length;
        int r = 0;
        int c = 0;
        for(int i=0;i<n-1;i++){
            for(int j=i+1;j<n;j++){
                if(target == array[i] + array[j]){
                    r = i + 1;
                    c = j + 1;
                    found = true;
                    break;
                }
            }
            if(found){
                break;
            }
        }
        if(found == expectedFound && (r == expectedIndex1 && c == expectedIndex2)) {
            System.out.println("Test Passed: Found index " + r + " and " + c + " with target " + target);
        } else if(!expectedFound && !found) {
            System.out.println("Test Passed: No pairs found for target " + target);
        } else {
            System.out.println("Test Failed: Unexpected result for array " + java.util.Arrays.toString(array) + " with target " + target);
        }
    }
}