import java.util.Scanner;
public class FindCommonIntegers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int[] arr1 = new int[size];
        int[] arr2 = new int[size];
        int[] result = new int[size];
        int index=0;
        for(int i=0;i<size;i++){
            arr1[i] = sc.nextInt();
        }
        for(int i=0;i<size;i++){
            arr2[i] = sc.nextInt();
        }
        for(int i=0;i<size;i++){
            for(int j=0;j<size;j++){
                if(arr1[i]==arr2[j]){
                    result[index++] = arr1[i];
                    break;
                }
            }
        }
        for(int i=0;i<index;i++){
            System.out.print(result[i]+" ");
        }
    }
}