import java.util.*;

public class CountVowelsConsonants {
    
   public static int[] CountVowels(String a)
   {
        char[] b=a.toCharArray();
        int c=0,v=0;
        for(int i=0;i<b.length;i++)
        {
            if(b[i]=='a'||b[i]=='e'||b[i]=='i'||b[i]=='o'||b[i]=='u')
            {
                v++;
            }
            else if(b[i]!=' ')
            {
                c++;
            }
        }
        return new int[]{v,c};

   }
   {

   }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a=sc.nextLine();
        a=a.toLowerCase();
        int [] b=new int[2];
        b=CountVowels(a);
        System.out.println("vowels: "+b[0]+" consonants: "+b[1]);
        sc.close();
    }
}