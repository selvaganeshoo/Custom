/**
 * Test Array Equality
 * 
 * Write a Java program to test the equality of two arrays.
 */
import java.util.Arrays;
import java.util.Scanner;
public class TestArrayEquality {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a1 = new int[n];
        int[] a2 = new int[n];
        for(int i=0;i<n;i++){
            a1[i]=sc.nextInt();
        }
        for(int i=0;i<n;i++){
            a2[i]=sc.nextInt();
        }
        System.out.println(Arrays.equals(a1, a2));
    }
} 