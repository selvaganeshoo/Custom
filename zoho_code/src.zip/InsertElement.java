import java.util.Scanner;
import java.util.Arrays;

/**
 * Insert Element at Position
 * 
 * Write a Java program to insert an element at a specific position into an array.
 */

public class InsertElement {
    
    
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size");
        int n=sc.nextInt();
        int[] a=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        int x=0,y=0;
        System.out.println("enter element "+x+" and position "+y);
        x=sc.nextInt();
        y=sc.nextInt();
        int j=0;
        int[] b=new int[n+1];
        for(int i=0;i<n+1;i++)
        {
            if(i==y)
            {
                b[i]=x;
            }
            else{
                b[i]=a[j];
                j++;
            }
        }
        System.out.println(Arrays.toString(b));
        sc.close();
    }
}