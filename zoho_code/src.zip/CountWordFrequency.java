import java.util.*;
public class CountWordFrequency {
    
    
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a=sc.nextLine();
        String[] b=a.split("\\s");
        boolean[] c=new boolean[b.length];
        for(int i=0;i<b.length;i++)
        {
            if(c[i]==true)
                {
                    continue;
                }
           
            int count=1;
            for(int j=i+1;j<b.length;j++)
            {
                
                if(b[i].equals(b[j]))
                {
                    count++;
                    c[j]=true;
                }
            }
            System.out.println(b[i]+":"+count);
            count=0;
        }
        sc.close();
    }
} 