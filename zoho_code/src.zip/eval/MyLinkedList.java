package eval;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Hashtable;
import java.
Iterator
public class MyLinkedList<T> {
    private Node head;
    private Node tail;
    Integer
    private int size;
    private class Node{
        public Node prev;
        public T data;
        public Node next;
        Node(T data){
            this.data = data;
        }
    }
    MyLinkedList(){
        this.head = null;
        this.tail = null;
        this.size = 0;
    }
    public void addLast(T a){
        Node newNode = new Node(a);
        if(head == null && tail == null){
            head = newNode;
            tail = newNode;
            newNode.prev = null;
            newNode.next = null;
        }else{
            tail.next = newNode;
            newNode.prev = tail;
            newNode.next = null;
            tail = newNode;
        }
        size++;
    }
    public void addAt(int p,T a){
        if(p>size||p<0){
            throw new IndexOutOfBoundsException();
        }
        Node newNode = new Node(a);
        if(p==0){
            newNode.next = head;
            newNode.prev = null;
            head = newNode;
        }
        else if(p==size+1){
            addLast(a);
        }
        else{
            Node current = head;
            for(int i=0;i<p;i++){
                current = current.next;
            }
            Node previous = current.prev;
            newNode.prev = previous;
            newNode.next = current;
            previous.next = newNode;
            current.prev = newNode;
        }
    }
    public String toString(){
        StringBuilder bi = new StringBuilder();
        bi.append("[");
        Node current = head;
        while(current!=null){
            bi.append(current.data);
            if(current.next!=null){
                bi.append(", ");
            }
            current = current.next;
        }
        bi.append("]");
        return bi.toString();
    }
    public static void main(String[] args) {
        MyLinkedList<String> a = new MyLinkedList<>();
        a.addLast("Head");
        a.addLast("Box1");
        a.addLast("Box2");
        a.addLast("Box3");
        a.addLast("Box4");
        a.addLast("Box5");
        a.addLast("Box6");
        a.addLast("Box7");
        a.addLast("Box8");
        a.addLast("Box9");
        a.addLast("Tail");
        System.out.println(a);
        a.addAt(1, "Box0");
        System.out.println(a);
    }
}