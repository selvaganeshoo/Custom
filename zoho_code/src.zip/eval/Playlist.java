package eval;
import java.util.LinkedList;
import javax.transaction.InvalidTransactionException;
public class Playlist {
    private LinkedList<String> A = new LinkedList<>();
    private void add(String a){
        A.add(a);
    }
    private String get(int index){
        if(index>A.size()||index<0){
            throw new InvalidTrackSelectionException();
        }
        return A.get(index);
    }
    public static void main(String[] args) {
        Playlist song = new Playlist();
        song.add("A");
        song.add("A");
        song.add("D");
        song.add("B");
        song.add("C");
        song.add("AD");
        song.add("eE");
        song.add("AF");
        song.add("eG");
        song.add("AH");
        song.add("I");
        song.add("J");
        song.add("K");
        song.add("L");
        song.add("M");
        song.add("N");
        System.out.println(song.get(1));
        System.out.println(song.get(3));
        System.out.println(song.get(2));
        System.out.println(song.get(4));
        System.out.println(song.get(5));
        System.out.println(song.get(30));
    }
}
class InvalidTrackSelectionException extends RuntimeException{
    public InvalidTrackSelectionException(){
        System.out.println("Invalid Track Selection Track Not Found");
    }
}