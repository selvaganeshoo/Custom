package eval;
import java.util.Arrays;
import java.util.EmptyStackException;
public class CustomStack {
    private int maxsize = 100;
    private Object stack[];
    private int modCount = 0;
    private int capacity;
    CustomStack(){
        this.capacity += 10;
        stack = new Object[capacity];
    }
    public int size(){
        return stack.length;
    }
    public void push(Object a){
        if(size()>=maxsize){
            throw new StackOverflowError();
        }
        else if(modCount==size()-2){
            int newcapacity = this.capacity+10;
            stack = Arrays.copyOf(stack,newcapacity);
        }
        stack[modCount++] = a;
    }
    public boolean isEmpty(){
        if(modCount<0){
            return true;
        }else{
            return false;
        }
    }
    public Object pop(){
        if(modCount<0){
            throw new EmptyStackException();
        }else{
            Object p = stack[modCount];
            stack[modCount--] = null;
            return p;
        }
    }
    public Object peek(){
        if(modCount<0){
            throw new EmptyStackException();
        }
        else{
            int i = modCount-1;
            return stack[i];
        }
    }
    @Override
    public String toString(){
        StringBuilder bi = new StringBuilder();
        bi.append("[");
        for(int i=0;i<modCount;i++){
            if(i==modCount-1){
                bi.append(stack[i]);
                break;
            }
            bi.append(stack[i]);
            bi.append(", ");
        }
        bi.append("]");
        return bi.toString();
    }
    public static void main(String[] args) {
        CustomStack a =new CustomStack();
        System.out.println(a.modCount);
        a.push("hello");
        a.push("Iam");
        a.push("selva");
        System.out.println(a);
        System.out.println(a.modCount);
        System.out.println(a.peek());
        a.pop();
        a.pop();
        System.out.println(a);
        a.push("hello");
        a.push("Iam");
        a.push("selva");
        a.push("ganesh");
        a.push("how");
        a.push("are");
        a.push("u");
        a.push("Iam");
        a.push("selva");
        a.push("hello");
        a.push("Iam");
        a.push("selva");
        System.out.println(a);
        System.out.println(a.size());
        System.out.println(a.modCount);
    }
}