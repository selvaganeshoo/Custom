package eval;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class LogAnalyzer {
    FileReader a;
    public LogAnalyzer()throws FileNotFoundException{
    this.a = new FileReader("Playlist");
    
    }
}
