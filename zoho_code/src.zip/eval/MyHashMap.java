package eval;
public class MyHashMap<K,V> {
    private Node<K,V> [] table;
    private int DEFAULT_INITIAL_CAPACITY = 16;
    private class Node<K,V>{
        private K key;
        private V value;
        Node(K key,V value){
            this.key = key;
            this.value = value;
        }
    }
    MyHashMap(K key,V value){
        table = new Node[DEFAULT_INITIAL_CAPACITY];
    }
    public String toString(){
        StringBuilder bi = new StringBuilder();
        bi.append("[");
        
        while()
    }
    public boolean put(K key,V value){
        table[0].key = key;
        table[0].value = value;
        return true; 
    }
}