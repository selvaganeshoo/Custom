package Assignments.OOPS.Polymorphism;

public class Guitar implements Playable {
    public void play()
    {
        System.out.println("Guitar : Implemented from playable");
    }

}
