package Assignments.OOPS.Polymorphism;

public class Cat extends Animal {
    public void speak()
    {
        System.out.println("Cat says meow!");
    }
}
