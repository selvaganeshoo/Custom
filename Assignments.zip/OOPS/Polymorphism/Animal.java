package Assignments.OOPS.Polymorphism;

public class Animal {
    public void speak()
    {
        System.out.println("The animal says roar");
    }
}
