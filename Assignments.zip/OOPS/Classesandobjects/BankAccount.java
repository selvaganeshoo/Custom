package Assignments.OOPS.Classesandobjects;

public class BankAccount {
private  int accountnumber;
private int balance;
public int accounttype;
public int getAccountnumber() {
    return this.accountnumber;
}
public  void setAccountnumber(int accountnumber) {
    this.accountnumber = accountnumber;
}
public  int getBalance() {
    return this.balance;
}
public void setBalance(int balance) {
    this.balance = balance;
}
public int getAccounttype() {
    return this.accounttype;
}
public void setAccounttype(int accounttype) {
    this.accounttype = accounttype;
}
}
