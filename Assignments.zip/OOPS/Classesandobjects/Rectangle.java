package Assignments.OOPS.Classesandobjects;

public class Rectangle {
    private double length;
    private double width;
    public double area(double l,double b)
    {
        return l*b;
    }
     public double Perimeter(double l,double b)
    {
        return 2.0*(l+b);
    }

}
