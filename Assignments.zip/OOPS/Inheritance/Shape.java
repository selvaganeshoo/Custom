package Assignments.OOPS.Inheritance;

public class Shape {
    private double numSides;
    private double area;
    public Shape(double numSides,double area)
    {
        this.area=area;
        this.numSides=numSides;
    }
    public double getNumSides() {
        return numSides;
    }
    public void setNumSides(double numSides) {
        this.numSides = numSides;
    }
    public double getArea() {
        return area;
    }
    public void setArea(double area) {
        this.area = area;
    }
   
    
}
