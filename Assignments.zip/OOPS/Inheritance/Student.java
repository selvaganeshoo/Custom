package Assignments.OOPS.Inheritance;

public class Student {
    private char grade;
    private String school;
    public Student(char g,String s)
    {
        this.grade=g;
        this.school=s;
    }
    public char getGrade() {
        return grade;
    }
    public String getSchool() {
        return school;
    }
}
