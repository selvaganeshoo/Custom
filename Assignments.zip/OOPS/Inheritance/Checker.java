package Assignments.OOPS.Inheritance;
public class Checker {
    public static void main(String[] args) {
        Dog myDog = new Dog("Buddy", 3, "Canine", "Golden Retriever", "Golden");
        myDog.displayInfo();
        Animal a = new Animal("Sheikh",99,"Alien");
        a.displayInfo();
        Vehicle b = new Vehicle("X", "tilt", 2002);
        b.displayInfo();
        Car c = new Car("Y", "rotate", 2006, "white", 2);
        c.displayInfo();
        Rectangle rect = new Rectangle(5.0, 3.0);
        System.out.println("Rectangle sides: " + rect.getNumSides());
        System.out.println("Length: " + rect.getLength());
        System.out.println("Width: " + rect.getWidth());
        System.out.println("Area: " + rect.getArea());
        Cat d = new Cat("Sheik", 1, "Cat", "white", 7);
        d.displayInfo();
}
}
