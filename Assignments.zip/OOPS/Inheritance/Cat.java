package Assignments.OOPS.Inheritance;

public class Cat extends Animal {
    private String color;
    private int numlives;
    public Cat(String name,int age,String species,String color, int numlives)
    {
        super(name,age,species);
        this.color=color;
        this.numlives=numlives;
    }
    @Override
    public void displayInfo()
    {
        super.displayInfo();
        System.out.println("color is: "+color);
        System.out.println("number of lives is: "+numlives);
    }
}
