package Assignments.OOPS.Easy;
public class Easy {

    public Double calculateAverage(int[] a)
    {
        int sum=0;
        for(int i=0;i<a.length;i++)
        {
            sum+=a[i];
        }
        return (double)sum/a.length;
    }
    public String reverseString(String a)
    {
        StringBuilder b= new StringBuilder(a);
        b.reverse();
        return new String(b);
    }
    public boolean isPalindrome(String a)
    {
        boolean pali=true;
        int l=0;
        int r=a.length()-1;
        while(l<=r)
        {
            if(a.charAt(l)!=a.charAt(r))
            {
                pali=false;
                break;
            }
            l++;
            r--;
        }
        return pali;
    }
    public int max(int[] a)
    {
        int k=a[0];
        for(int i=1;i<a.length;i++)
        {
            int t=0;
            if(k<a[i])
            {
               k=a[i];
            }
        }
        return k;
    }
    public int fact(int a)
    {
        int f=1;
        for(int i=1;i<=a;i++)
        {
            f*=i;
        }
        return f;
    }
}
