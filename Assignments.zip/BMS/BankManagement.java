package Assignments.BMS;
import java.util.Scanner;
public class BankManagement {
    public static void listallAccount(){
        System.out.println("Listing All Accounts in our Bank");
    }
    public static void highestBalance(){
        System.out.println("Highest balance holder in our Bank");
    }
    public static void totalBalance(){
        System.out.println("Total Balance of our Bank");
    }
     public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        int choice;
        do{
            choice=s.nextInt();
            switch(choice){
                case 1:
                    System.out.println("1.List all Accounts in our Bank");
                    listallAccount();
                    break;
                case 2:
                    System.out.println("2.View Highest Balance holder in our Bank");
                    highestBalance();
                    break;
                case 3:
                    System.out.println("3.View Total Balance in our Bank");
                    totalBalance();
                    break;
                case 0:
                    System.out.println("0.Exit");
                default:
                    System.out.println("Invalid input");
            }
        }while(choice!=0);
    }
}
