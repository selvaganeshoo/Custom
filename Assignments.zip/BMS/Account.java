package Assignments.BMS;
public class Account{
    private String accountnum;
    private String Name;
    private double balance;
    Account(String accountnum,String Name,double balance){
        this.accountnum=accountnum;
        this.Name=Name;
        this.balance=balance;
    }
    public String getname(){
        return Name;
    }
}