package Assignments.BMS;
public interface Transaction {
    public double deposit(String name,String accnum);
    public double withdraw(String name,String accnum);
}