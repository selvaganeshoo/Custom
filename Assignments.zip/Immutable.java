package Assignments;
import java.util.Scanner;
public final class Immutable{
    private final int n;
    Immutable(int n){
        this.n=n;
    }
    Immutable Multiply(int f){
        f=n*f;
        return new Immutable(f);
    }
    @Override
    public String toString(){
        return String.valueOf(n);
    }
    public static void main(String[] args){
        int n=0;
        int multiples = 10;
        Scanner s = new Scanner(System.in);
        while(n<=6){
            System.out.println("Enter the new object ");
            Immutable c = new Immutable(s.nextInt());
            System.out.println(c);
            System.out.println(c.Multiply(multiples));
            n++;
        }
    }
}