package Assignments.LibraryManagement;
class Book {
     private int id;
    private String title;
    private String author;
    private boolean isIssued;
    Book(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.isIssued = false;
    }
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public boolean isIssued() { return isIssued; }
    public void issueBook() { isIssued = true; }
    public void returnBook() { isIssued = false; }
    // ✅ Override toString
    @Override
    public String toString() {
        return id + ". " + title + " by " + author + (isIssued ? " (Issued)" : " (Available)");
    }
    // ✅ equals & hashCode (based on title + author)
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Book)) return false;
        Book b = (Book) obj;
        return this.title.equals(b.title) && this.author.equals(b.author);
    }
    @Override
    public int hashCode() {
        return title.hashCode() + author.hashCode();
    }
}
// ✅ Abstraction
abstract class User {
    String name;
    User(String name) { this.name = name; }  // constructor chaining
    abstract void showRole(); // abstract method
}
// ✅ Inheritance + Polymorphism
class Student extends User {
    Student(String name) { super(name); }
    @Override
    void showRole() { System.out.println("Student: " + name); }
}
