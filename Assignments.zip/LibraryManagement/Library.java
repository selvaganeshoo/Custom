package Assignments.LibraryManagement;
class Library {
    private static Library instance;
    private Book[] books;
    private int count;
    private Library() { // private constructor
        books = new Book[10]; // max 10 books
        count = 0;
    }
    public static Library getInstance() {
        if (instance == null) instance = new Library();
        return instance;
    }
    public void addBook(String title, String author) {
        for (int i = 0; i < count; i++) {
            if (books[i].getTitle().equals(title) && books[i].getAuthor().equals(author)) {
                System.out.println("Book already exists!");
                return;
            }
        }
        if (count < books.length) {
            books[count] = new Book(count + 1, title, author);
            count++;
            System.out.println("Book added!");
        } else {
            System.out.println("Library is full!");
        }
    }
    public void viewBooks() {
        if (count == 0) {
            System.out.println("No books available.");
            return;
        }
        for (int i = 0; i < count; i++) {
            System.out.println(books[i]);
        }
    }
    public void issueBook(int id) {
        for (int i = 0; i < count; i++) {
            if (books[i].getId() == id) {
                if (!books[i].isIssued()) {
                    books[i].issueBook();
                    System.out.println("Book issued: " + books[i].getTitle());
                } else {
                    System.out.println("Book already issued!");
                }
                return;
            }
        }
        System.out.println("Book not found.");
    }
    public void returnBook(int id) {
        for (int i = 0; i < count; i++) {
            if (books[i].getId() == id) {
                if (books[i].isIssued()) {
                    books[i].returnBook();
                    System.out.println("Book returned: " + books[i].getTitle());
                } else {
                    System.out.println("Book was not issued!");
                }
                return;
            }
        }
        System.out.println("Book not found.");
    }
}

