package Assignments.HundredProblems;
class Eval1{
    public static void main(String[] args) {
        String a = "hello";
        String b = new String();
        b = "hello";
        b = "hi";
        a = "done";
        System.out.println(b);
        System.out.println(a);
    }
}