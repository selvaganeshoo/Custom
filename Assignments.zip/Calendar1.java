package Assignments;
import java.util.Scanner;
public class Calendar1
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter date");
        int date=sc.nextInt();
        System.out.println("enter month");
        int m=sc.nextInt();
        System.out.println("enter year");
        int y=sc.nextInt();
        int days=0;
        for(int i=1900;i<y;i++)
        {
            if((i%4==0&&i%100!=0)||(i%400==0))
            {
                days+=366;
            }
            else{
                days+=365;
            }
        }
        for(int i=1;i<m;i++)
        {
            if(i==1||i==3||i==5||i==7||i==8||i==10||i==12)
            {
                days+=31;
            }
            else if(i==2)
            {
                if((i%4==0&&i%100!=0)||(i%400==0))
            {
                days+=29;
            }
            else{
                days+=28;
            }
            }
            else
            {
                days+=30;
            }
        }
        
int k = (1 + days) % 7;


int daysInMonth;
if (m == 2) {
    if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)) {
        daysInMonth = 29;
    } else {
        daysInMonth = 28;
    }
} else if (m == 4 || m == 6 || m == 9 || m == 11) {
    daysInMonth = 30;
} else {
    daysInMonth = 31;
}

System.out.println("\nSun Mon Tue Wed Thu Fri Sat");


for (int i = 0; i < k; i++) {
    System.out.print("    ");
}

for (int d = 1; d <= daysInMonth; d++) {
    if (d == date) {
        System.out.printf("[%2d]", d);  
    } else {
        System.out.printf(" %2d ", d);
    }

    k++;
    if (k % 7 == 0) {
        System.out.println(); 
    }
}
System.out.println();

        
    
        sc.close();
    }
}
