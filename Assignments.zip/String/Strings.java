package Assignments.String;
public class Strings{
    private final char string[];
    private final int length;
/*

        CONSTRUCTORS STARTS HERE

*/
    public Strings(char[] string){
        length=string.length;
        this.string=new char[length];
        for(int i=0;i<length;i++){
            this.string[i]=string[i];
        }
    }
    public Strings(Strings another){
        this.length = another.length;
        this.string = new char[length]; 
        for (int i = 0; i < length; i++) { 
        this.string[i] = another.string[i];
        }                  
    }
    public Strings(String another){
        this.length=another.length();
       this.string=new char[another.length()];
       for(int i=0;i<length;i++){
        this.string[i]=another.charAt(i);
       }
    }
    public Strings(String original, int start, int end) {
    if (start < 0 || end > original.length() || start > end) {
        throw new StringIndexOutOfBoundsException("Invalid range");
    }
    this.length = end - start;
    this.string = new char[this.length];
    for (int i = 0; i < this.length; i++) {
        this.string[i] = original.charAt(start + i);
    }
    } 
    public Strings(Strings original, int start, int end) {
        if (start < 0 || end > original.length || start > end) {
        throw new StringIndexOutOfBoundsException("Invalid range");
    } 
    this.length = end-start;                      
    this.string = new char[this.length];           
    for (int i = 0; i < this.length; i++) {       
        this.string[i] = original.string[start+i];
    }
    }
    public Strings(char[] original, int start, int end) {
        if (start < 0 || end > original.length || start > end) {
        throw new StringIndexOutOfBoundsException("Invalid range");
    } 
    this.length = end-start;                      
    this.string = new char[this.length];           
    for (int i = 0; i < this.length; i++) {       
        this.string[i] = original[start+i];
    }
    }
    public Strings(byte[] bytes) {
    this.length = bytes.length;
    this.string = new char[this.length];
    for (int i = 0; i < this.length; i++) {
        this.string[i] = (char)(bytes[i] & 0xFF); 
    }
    }
    public Strings(int[] codePoints, int offset, int count){
        this.length = count-offset;
    this.string = new char[this.length];
    for (int i = 0; i < this.length; i++) {
        this.string[i] = (char)(codePoints[i+offset] & 0xFFFF); 
    }
    }
    public Strings(Stringbuilder another){
        this.length = another.length;
        this.string=new char[this.length];
        for(int i=0;i<length;i++){
            this.string[i]=another.string[i];
        }
    }
    public Strings(Stringbuffer another){
        this.length = another.length;
        this.string=new char[this.length];
        for(int i=0;i<length;i++){
            this.string[i]=another.string[i];
        }
    }
/*

        CONSTRUCTORS ENDS HERE

*/
    public int lengths(){
        return this.string.length;
    }
    public boolean isempty(Strings another){
        return length==0;
    }
    public boolean isempty(String another){
        return another.length()==0;
    }
     public boolean isblank(Strings string) {
        if (length == 0) {
            return true; 
        }
        for (int i = 0; i < length; i++) {
            char c = this.string[i];
            if (!(c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f')) {
                return false;
            }
        }
        return true;
    }
     public boolean isblank(String another) {
        if (length == 0) {
            return true; 
        }
        for (int i = 0; i < length; i++) {
            char c = charat(i);
            if (!(c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f')) {
                return false;
            }
        }
        return true;
    }
    public char charat(int n){
        if (n < 0) {
            n = this.lengths() + n; 
        }
        if (n < 0 || n >= string.length) {
            throw new StringIndexOutOfBoundsException(n);
        }
        return this.string[n];
    }
    public Strings subsstring(int s,int e){
        if (s < 0 || e > this.string.length || s > e) {
        throw new StringIndexOutOfBoundsException("Invalid substring range");
    }
        int len=e-s;
        char[] t= new char[len];
        int st=0;
        for(int i=s;i<e;i++){
            t[st]=this.string[i];
            st++;
        }
        return new Strings(t);
    }
    public int compareTo(String another) {
    int minLen = Math.min(this.length, another.length());
    for (int i = 0; i < minLen; i++) {
        if (this.string[i] != another.charAt(i)) {
            return this.string[i] - another.charAt(i);
        }
    }
    return this.length - another.length();
    }
    public int compareTo(Strings another) {
    int minLen = Math.min(this.length, another.length);
    for (int i = 0; i < minLen; i++) {
        if (this.string[i] != another.string[i]) {
            return this.string[i] - another.string[i];
        }
    }
    return this.length - another.length;
    }

    public boolean equal(Strings string1) {
    if (string.length != string1.string.length) {
        return false;
    }
    for (int i = 0; i < this.string.length; i++) {
        if (this.string[i] != string1.string[i]) {
            return false;
        }
    }
    return true;
    }
    public Strings conCat(Strings n){
        int len = this.lengths() + n.lengths();
        char[] N = new char[len];
        int i = 0;
        for (int k = 0; k < this.lengths(); k++) {
            N[i++] = this.string[k];
        }
        for (int m = 0; m < n.lengths(); m++) {
        N[i++] = n.string[m];
        }
        return new Strings(N);
    }
    public Strings toupper() {
    char[] a = new char[this.string.length];
    for (int i = 0; i < this.string.length; i++) {
        char ch = this.string[i];
        if (ch >= 'a' && ch <= 'z') {
            a[i] = (char) (ch - 32); 
        } else {
            a[i] = ch;
        }
    }
    return new Strings(a);
    }
    public Strings tolower(){
        char[] a = new char[this.string.length];
    for (int i = 0; i < this.string.length; i++) {
        char ch = this.string[i];
        if (ch >= 'A' && ch <= 'Z') {
            a[i] = (char) (ch + 32); 
        } else {
            a[i] = ch;
        }
    }
    return new Strings(a);
    }
    @Override
    public String toString() {
        return new String(this.string);
    }
    public int indexof(char ch) {
    for (int i = 0; i < this.string.length; i++) {
        if (this.string[i] == ch) {
            return i;
        }
    }
        return -1; 
    }
    public int lastindexof(char c){
        for(int i=length-1;i>=0;i--){
            if(this.string[i]==c){
                return i;
            }
        }
        return -1;
    }
    public boolean endswith(String prefix) {
    if (prefix.length() > this.lengths()) {
        return false;
    }
    int offset = this.lengths() - prefix.length();
    for (int i = 0; i < prefix.length(); i++) {
        if (this.string[offset + i] != prefix.charAt(i)) {
            return false;
        }
    }
    return true;
    }

    public boolean endswith(Strings prefix) {
    if (prefix.lengths() > this.lengths()) {
        return false;
    }
    int offset = this.lengths() - prefix.lengths();
    for (int i = 0; i < prefix.lengths(); i++) {
        if (this.string[offset + i] != prefix.string[i]) {
            return false;
        }
    }
    return true;
    }

    public boolean startswith(Strings prefix) {
    if (prefix.lengths() > this.lengths()) {
        return false;
    }
    for (int i = 0; i < prefix.lengths(); i++) {
        if (this.string[i] != prefix.string[i]) {
            return false; 
        }
    }
    return true; 
    }
    public boolean startswith(String prefix) {
    if (prefix.length() > this.lengths()) {
        return false;
    }
    for (int i = 0; i < prefix.length(); i++) {
        if (this.string[i] != prefix.charAt(i)){
            return false; 
        }
    }
    return true; 
    }
    public boolean Contains(Strings another) {
    if (another.lengths() > this.lengths()) {
        return false;
    }
    for (int i = 0; i <= this.lengths() - another.lengths(); i++) {
        int j = 0;
        while (j < another.lengths() && this.string[i + j] == another.string[j]) {
            j++;
        }
        if (j == another.lengths()) {
            return true; 
        }
    }
    return false;
    }
    public boolean Contains(String another) {
    if (another.length() > this.lengths()) {
        return false;
    }
    for (int i = 0; i <= this.lengths() - another.length(); i++) {
        int j = 0;
        while (j < another.length() && this.string[i + j] == another.charAt(j)) {
            j++;
        }
        if (j == another.length()) {
            return true; 
        }
    }
    return false;
    }
}