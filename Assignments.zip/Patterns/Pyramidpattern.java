package Assignments.Patterns;
import java.util.Scanner;
public class Pyramidpattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of rows: ");
        int rows=sc.nextInt();
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<rows;j++)
            {
                if(j>=rows-i-1&&j<rows+i)
                {
                    System.out.print("* ");
                }
                else
                {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
