package Assignments.SnakeAndLadderGame;
public interface Playable {
    public int roll();
}