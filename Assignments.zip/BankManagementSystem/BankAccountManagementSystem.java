package Assignments.BankManagementSystem;
import java.util.Scanner;
public class BankAccountManagementSystem {
    private static final int MAX_ACCOUNTS = 100; 
    private static Account[] accounts = new Account[MAX_ACCOUNTS];
    private static int accountCount = 0;
    private static Scanner sc = new Scanner(System.in);

    
    private static void createAccount() {
        if (accountCount >= MAX_ACCOUNTS) {
            System.out.println(" Cannot create more accounts (limit reached).");
            return;
        }

        System.out.print("Enter Account Number: ");
        String accNum = sc.next();

        System.out.print("Enter Holder Name: ");
        String name = sc.next();

        System.out.print("Enter Initial Balance: ");
        double balance = sc.nextDouble();

        System.out.print("Enter Account Type (1-Savings / 2-Current): ");
        int choice = sc.nextInt();

        Account acc;
        if (choice == 1) {
            acc = new SavingsAccount(accNum, name, balance);
        } else if(choice==2) {
            acc = new CurrentAccount(accNum, name, balance);
        }
        else{
            System.out.println("Invalid option try again");
            return;
        }

        accounts[accountCount++] = acc;
        System.out.println(" Account created successfully!\n");
    }

    
    private static Account findAccount(String accNum) {
        for (int i = 0; i < accountCount; i++) {
            if (accounts[i].getAccountNumber().equals(accNum)) {
                return accounts[i];
            }
        }
        return null;
    }

    
    private static void depositMoney() {
        System.out.print("Enter Account Number: ");
        String accNum = sc.next();
        Account acc = findAccount(accNum);
        if (acc != null) {
            System.out.print("Enter Amount to Deposit: ");
            acc.deposit(sc.nextDouble());
        } else {
            System.out.println("Account not found!");
        }
    }

    private static void withdrawMoney() {
        System.out.print("Enter Account Number: ");
        String accNum = sc.next();
        Account acc = findAccount(accNum);
        if (acc != null) {
            System.out.print("Enter Amount to Withdraw: ");
            acc.withdraw(sc.nextDouble());
        } else {
            System.out.println("Account not found!");
        }
    }

    
    private static void viewDetails() {
        System.out.print("Enter Account Number: ");
        String accNum = sc.next();
        Account acc = findAccount(accNum);
        if (acc != null) {
            acc.displayDetails();
        } else {
            System.out.println("Account not found!");
        }
    }

    
    private static void listAllAccounts() {
        System.out.println("\n--- All Accounts ---");
        for (int i = 0; i < accountCount; i++) {
            accounts[i].displayDetails();
        }
    }

   
    private static void highestBalanceAccount() {
        if (accountCount == 0) {
            System.out.println("No accounts available!");
            return;
        }
        Account highest = accounts[0];
        for (int i = 1; i < accountCount; i++) {
            if (accounts[i].getBalance() > highest.getBalance()) {
                highest = accounts[i];
            }
        }
        System.out.println("\n--- Account with Highest Balance ---");
        highest.displayDetails();
    }

    
    private static void totalBalance() {
        double total = 0;
        for (int i = 0; i < accountCount; i++) {
            total += accounts[i].getBalance();
        }
        System.out.println("\n Total Balance in Bank: " + total);
    }

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n--- Bank Account Management System ---");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit Money");
            System.out.println("3. Withdraw Money");
            System.out.println("4. View Account Details");
            System.out.println("5. List All Accounts");
            System.out.println("6. Account with Highest Balance");
            System.out.println("7. Total Balance in Bank");
            System.out.println("0. Exit");
            System.out.print("Enter Choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1: createAccount(); 
                break;
                case 2: depositMoney(); 
                break;
                case 3: withdrawMoney(); 
                break;
                case 4: viewDetails(); 
                break;
                case 5: listAllAccounts(); 
                break;
                case 6: highestBalanceAccount(); 
                break;
                case 7: totalBalance(); 
                break;
                case 0: System.out.println("Exiting... Thank you!"); 
                break;
                default: System.out.println("Invalid choice! Try again.");
            }
        } while (choice != 0);
    }
}
