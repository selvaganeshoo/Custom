package Assignments.Student;
class School {
    private String schoolName;
    private Student[] students;
    private Teacher[] teachers;
    private int studentCount;
    private int teacherCount;

    public School(String schoolName, int maxStudents, int maxTeachers) {
        this.schoolName = schoolName;
        this.students = new Student[maxStudents];
        this.teachers = new Teacher[maxTeachers];
        this.studentCount = 0;
        this.teacherCount = 0;
    }

    public void addStudent(Student s) {
        if (studentCount < students.length) {
            students[studentCount++] = s;
        }
    }

    public void addTeacher(Teacher t) {
        if (teacherCount < teachers.length) {
            teachers[teacherCount++] = t;
        }
    }

    public void showAllMembers() {
        System.out.println("\n=== Members of " + schoolName + " ===");
        for (int i = 0; i < studentCount; i++) {
            students[i].showRole();
        }
        for (int i = 0; i < teacherCount; i++) {
            teachers[i].showRole();
        }
    }

    public Student getBestStudent() {
        if (studentCount == 0) return null;
        Student best = students[0];
        for (int i = 1; i < studentCount; i++) {
            if (students[i].calculateAverage() > best.calculateAverage()) {
                best = students[i];
            }
        }
        return best;
    }

    public Student getLowestStudent() {
        if (studentCount == 0) return null;
        Student worst = students[0];
        for (int i = 1; i < studentCount; i++) {
            if (students[i].calculateAverage() < worst.calculateAverage()) {
                worst = students[i];
            }
        }
        return worst;
    }

    public String getBestClass() {
        if (studentCount == 0) return null;
        String bestClass = students[0].getGrade();
        double highestAvg = 0;

        for (int i = 0; i < studentCount; i++) {
            String currentGrade = students[i].getGrade();
            double total = 0;
            int count = 0;

            for (int j = 0; j < studentCount; j++) {
                if (students[j].getGrade().equals(currentGrade)) {
                    total += students[j].calculateAverage();
                    count++;
                }
            }

            double avg = total / count;
            if (avg > highestAvg) {
                highestAvg = avg;
                bestClass = currentGrade;
            }
        }
        return bestClass;
    }
}