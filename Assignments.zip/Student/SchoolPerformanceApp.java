package Assignments.Student;
public class SchoolPerformanceApp {
    public static void main(String[] args) {
        // Create school
        School school = new School("Green Valley High", 10, 5);

        // Create students
        Student s1 = new Student("Alice", 14, "8th", 5);
        s1.addMark(80, 90, 85);

        Student s2 = new Student("Bob", 15, "8th", 5);
        s2.addMark(60, 70, 65);

        Student s3 = new Student("Charlie", 14, "9th", 5);
        s3.addMark(95, 92, 96);

        // Add students
        school.addStudent(s1);
        school.addStudent(s2);
        school.addStudent(s3);

        // Create teachers
        Teacher t1 = new Teacher("Mr. John", 40, "Math");
        Teacher t2 = new Teacher("Mrs. Smith", 35, "Science");

        // Add teachers
        school.addTeacher(t1);
        school.addTeacher(t2);

        // Use methods (main just calls them)
        school.showAllMembers();
        System.out.println("\nBest Student: " + school.getBestStudent().getName());
        System.out.println("Lowest Student: " + school.getLowestStudent().getName());
        System.out.println("Best Performing Class: " + school.getBestClass());
    }
}