package Exceptions.Basic;
public class ExNo4 {
    public static void main(String[] args) {
        int a = 5;
        int b = 0;
        String c = null;
        try{
            System.out.println(a/b);
            System.out.println(c.length());
        }
        catch(ArithmeticException q){
            System.out.println(q);
            System.out.println(q.getMessage());
        }
        catch(NullPointerException w){
            System.out.println(w);
            System.out.println(w.getMessage());
        }
    }
}
