package Exceptions.Basic;
public class ExNo5 {
public static void main(String[] args) {
    try{
        Class.forName("arg0");
    }
    catch(ClassNotFoundException e){
        System.out.println(e);
    }
    finally{
        System.out.println("What's done is done when would i say it's done");
    }
}
}
