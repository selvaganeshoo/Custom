package exceptions.advanced;
public class InsufficientFundException extends RuntimeException{
    private int balance;
    private int amount;
    InsufficientFundException(int balance, int amount){
        super("Balance is less than withdraw Balance: "+ balance+"is balance but withdraw amount is "+amount);
        this.amount = amount;
        this.balance = balance;
            
    }    
}
