package exceptions.advanced;
import java.util.Scanner;
public class Checker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int age = sc.nextInt();
        try{
            if(age<18){
            throw new InvalidAgeException(age);
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        int balance = sc.nextInt();
        int amount = sc.nextInt();
        try{
        if(amount > balance){
            throw new InsufficientFundException(balance, amount);
        }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}
