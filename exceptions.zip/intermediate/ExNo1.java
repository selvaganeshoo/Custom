package exceptions.intermediate;
import java.util.InputMismatchException;
import java.util.Scanner;
public class ExNo1 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        try{
            int a = s.nextInt();
            String b = "hello";
            System.out.println(Integer.parseInt(b));
        }
        catch(InputMismatchException | NumberFormatException e){
            System.out.println(e);
        }
    }
}
