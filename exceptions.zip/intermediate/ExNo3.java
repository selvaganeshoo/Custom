package exceptions.intermediate;
public class ExNo3 {
    public static void main(String[] args){
        try{
            throw new Exception("message");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
